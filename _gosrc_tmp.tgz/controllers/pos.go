package controllers

import (
	"awesomeProject/config"
	"awesomeProject/models"
	"awesomeProject/utils"
	"encoding/json"
	"log"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// parsePOSsoldSNs extracts the individual SNs that were sold.
// The frontend sends a range like "SN001 → SN003 (3/10)" or a comma-separated list.
func parsePOSsoldSNs(raw string, expectedQty int) []string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return nil
	}
	// Try range format: "SN001 → SN003"
	rangeRe := regexp.MustCompile(`^(\S+)\s*→\s*(\S+)`)
	if m := rangeRe.FindStringSubmatch(raw); m != nil {
		startSN, endSN := m[1], m[2]
		// Extract numeric suffix from both
		numRe := regexp.MustCompile(`(\d+)$`)
		startNumStr := numRe.FindString(startSN)
		endNumStr := numRe.FindString(endSN)
		if startNumStr != "" && endNumStr != "" {
			startNum, _ := strconv.Atoi(startNumStr)
			endNum, _ := strconv.Atoi(endNumStr)
			prefix := startSN[:len(startSN)-len(startNumStr)]
			var sns []string
			for i := startNum; i <= endNum; i++ {
				sns = append(sns, prefix+strconv.Itoa(i))
			}
			if len(sns) > 0 {
				return sns
			}
		}
	}
	// Fallback: comma-separated or space-separated
	re := regexp.MustCompile(`[,\s\-]+`)
	parts := re.Split(raw, -1)
	var result []string
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" {
			result = append(result, p)
		}
	}
	return result
}

// POS sale input mirrors what the POS page sends (sale + nested line items).
type posSaleRequest struct {
	SubscriberID   uuid.UUID     `json:"subscriberId"`
	SubscriberName string        `json:"subscriberName"`
	TotalAmount    float64       `json:"totalAmount"`
	TaxAmount      float64       `json:"taxAmount"`
	PaymentMethod  string        `json:"paymentMethod"`
	Date           string        `json:"date"`
	IsInstallment  bool          `json:"isInstallment"`
	Status         string        `json:"status"`
	Discount       float64       `json:"discount"`
	Items          []posSaleItem `json:"items"`
}

type posSaleItem struct {
	ProductID     uuid.UUID `json:"productId"`
	ProductName   string    `json:"productName"`
	Quantity      int       `json:"quantity"`
	Price         float64   `json:"price"`
	OriginalPrice float64   `json:"originalPrice"`
	TaxPercent    float64   `json:"taxPercent"`
	SaleTax       float64   `json:"saleTax"`
	WthTax        float64   `json:"wthTax"`
	SerialNumber  string    `json:"serialNumber"`
	Model         string    `json:"model"`
}

type installmentRequest struct {
	InstallmentPlanID uuid.UUID `json:"installmentPlanId"`
}

// CreatePOSSale records a sale that is paid in full at the counter.
func CreatePOSSale(c *gin.Context) {
	companyID := c.MustGet("companyID").(uuid.UUID)

	var req posSaleRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.ErrorResponse(c, 400, "Invalid input data", err.Error())
		return
	}

	if len(req.Items) == 0 {
		utils.ErrorResponse(c, 400, "Sale must contain at least one item", "no items")
		return
	}

	// Build the sale + items models
	saleStatus := req.Status
	if saleStatus == "" {
		saleStatus = "completed"
	}
	sale := models.Sale{
		SubscriberID:   req.SubscriberID,
		SubscriberName: req.SubscriberName,
		TotalAmount:    req.TotalAmount,
		TaxAmount:      req.TaxAmount,
		PaymentMethod:  req.PaymentMethod,
		Date:           req.Date,
		IsInstallment:  req.IsInstallment,
		Status:         saleStatus,
		Discount:       req.Discount,
		Items:          make([]models.SaleItem, 0, len(req.Items)),
	}
	for _, it := range req.Items {
		sale.Items = append(sale.Items, models.SaleItem{
			ProductID:     it.ProductID,
			ProductName:   it.ProductName,
			Quantity:      it.Quantity,
			Price:         it.Price,
			OriginalPrice: it.OriginalPrice,
			TaxPercent:    it.TaxPercent,
			SaleTax:       it.SaleTax,
			WthTax:        it.WthTax,
			SerialNumber:  it.SerialNumber,
			Model:         it.Model,
		})
	}

	err := config.DB.Transaction(func(tx *gorm.DB) error {
		return recordPOSSale(tx, companyID, &sale, req.Items)
	})
	if err != nil {
		utils.ErrorResponse(c, 500, "Failed to record sale", err.Error())
		return
	}

	utils.CreatedResponse(c, "Sale recorded", sale)
}

// recordPOSSale persists a sale with its line items and consumes the matching
// stock and serial numbers, inside a caller-supplied transaction. Shared with the
// POS promise path, which records the same sale and only defers the money.
//
// The generic CRUD Create cannot do this because it does not persist nested
// slices or touch stock.
func recordPOSSale(tx *gorm.DB, companyID uuid.UUID, sale *models.Sale, items []posSaleItem) error {
	sale.CompanyID = companyID
	if err := tx.Create(sale).Error; err != nil {
		return err
	}
	return consumeSaleStock(tx, companyID, items)
}

// consumeSaleStock keeps the legacy product-level stock counters in sync with
// a sale. Purchase and vendor-invoice records are static documents (their
// quantity, serial numbers and models never change), so sold quantity is
// tracked exclusively by the sale_items rows; the POS page and the Stock page
// both derive the available quantity from (purchased - sold).
func consumeSaleStock(tx *gorm.DB, companyID uuid.UUID, items []posSaleItem) error {
	for _, it := range items {
		qty := it.Quantity
		if qty <= 0 {
			continue
		}

		soldSNs := parsePOSsoldSNs(it.SerialNumber, qty)

		// Serial-bearing sale: remove the sold SNs from products.serial_number
		// and sync the product's own stock counter with the remaining pool.
		if it.SerialNumber != "" && len(soldSNs) > 0 {
			var prod models.Product
			if err := tx.Where("id = ? AND company_id = ?", it.ProductID, companyID).First(&prod).Error; err != nil {
				continue
			}
			allSNs := prod.ParseSerialNumbers()
			if len(allSNs) == 0 {
				continue
			}
			consumedSet := make(map[string]bool, len(soldSNs))
			for _, sn := range soldSNs {
				consumedSet[sn] = true
			}
			var remaining []string
			for _, sn := range allSNs {
				if !consumedSet[sn] {
					remaining = append(remaining, sn)
				}
			}
			if err := tx.Model(&models.Product{}).
				Where("id = ? AND company_id = ?", it.ProductID, companyID).
				Updates(map[string]interface{}{
					"serial_number":        strings.Join(remaining, ", "),
					"stock":                len(remaining),
					"current_serial_index": 0,
				}).Error; err != nil {
				return err
			}
			continue
		}

		// Serial-less sale: decrement the product stock counter only. The
		// purchase records are never touched.
		if err := tx.Model(&models.Product{}).
			Where("id = ? AND company_id = ?", it.ProductID, companyID).
			Update("stock", gorm.Expr("GREATEST(stock - ?, 0)", qty)).Error; err != nil {
			return err
		}
	}
	return nil
}

// CreateInstallmentSale creates a sale with an installment plan for the subscriber.
// The first installment is paid at the time of creation.
func CreateInstallmentSale(c *gin.Context) {
	companyID := c.MustGet("companyID").(uuid.UUID)

	var req struct {
		SubscriberID      uuid.UUID     `json:"subscriberId"`
		SubscriberName    string        `json:"subscriberName"`
		InstallmentPlanID uuid.UUID     `json:"installmentPlanId"`
		Subtotal          float64       `json:"subtotal"`
		TaxAmount         float64       `json:"taxAmount"`
		Discount          float64       `json:"discount"`
		PaymentMethod     string        `json:"paymentMethod"`
		Date              string        `json:"date"`
		Items             []posSaleItem `json:"items"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		utils.ErrorResponse(c, 400, "Invalid input data", err.Error())
		return
	}

	if len(req.Items) == 0 {
		utils.ErrorResponse(c, 400, "Sale must contain at least one item", "no items")
		return
	}

	// Look up the installment plan
	var plan models.InstallmentPlan
	if err := config.DB.Where("id = ? AND company_id = ?", req.InstallmentPlanID, companyID).First(&plan).Error; err != nil {
		utils.ErrorResponse(c, 404, "Installment plan not found", err.Error())
		return
	}

	// Check if subscriber already has an active installment
	var existing models.SubscriberInstallment
	if err := config.DB.Where("subscriber_id = ? AND company_id = ? AND status = ?", req.SubscriberID, companyID, "active").First(&existing).Error; err == nil {
		utils.ErrorResponse(c, 400, "Subscriber already has an active installment plan", "active installment exists")
		return
	}

	// Calculate installment: apply percentage increase once to subtotal, then divide
	totalWithIncrease := req.Subtotal * (1 + plan.PercentageIncrease/100)
	amountPerInstallment := totalWithIncrease / float64(plan.Installments)

	sale := models.Sale{
		SubscriberID:   req.SubscriberID,
		SubscriberName: req.SubscriberName,
		TotalAmount:    totalWithIncrease + req.TaxAmount,
		TaxAmount:      req.TaxAmount,
		Discount:       req.Discount,
		PaymentMethod:  req.PaymentMethod,
		Date:           req.Date,
		IsInstallment:  true,
		Status:         "completed",
		Items:          make([]models.SaleItem, 0, len(req.Items)),
	}
	for _, it := range req.Items {
		sale.Items = append(sale.Items, models.SaleItem{
			ProductID:     it.ProductID,
			ProductName:   it.ProductName,
			Quantity:      it.Quantity,
			Price:         it.Price,
			OriginalPrice: it.OriginalPrice,
			TaxPercent:    it.TaxPercent,
			SaleTax:       it.SaleTax,
			WthTax:        it.WthTax,
			SerialNumber:  it.SerialNumber,
			Model:         it.Model,
		})
	}

	paymentDate := req.Date
	if paymentDate == "" {
		paymentDate = time.Now().Format(time.RFC3339)
	}

	err := config.DB.Transaction(func(tx *gorm.DB) error {
		sale.CompanyID = companyID
		if err := tx.Create(&sale).Error; err != nil {
			return err
		}

		// Create installment record — first installment is already paid
		installment := models.SubscriberInstallment{
			SaleID:            sale.ID,
			SubscriberID:      req.SubscriberID,
			SubscriberName:    req.SubscriberName,
			InstallmentPlanID: plan.ID,
			PlanName:          plan.Name,
			TotalInstallments: plan.Installments,
			PaidInstallments:  1,
			InstallmentAmount: amountPerInstallment,
			TotalAmount:       totalWithIncrease,
			NextInstallment:   2,
			Status:            "active",
		}
		if plan.Installments <= 1 {
			installment.Status = "completed"
			installment.PaidInstallments = plan.Installments
			installment.NextInstallment = 0
		}
		installment.CompanyID = companyID
		if err := tx.Create(&installment).Error; err != nil {
			return err
		}

		// Create Payment record for the first installment
		payment := models.Payment{
			TenantModel:    models.TenantModel{CompanyID: companyID},
			SubscriberID:   &req.SubscriberID,
			SubscriberName: req.SubscriberName,
			Amount:         amountPerInstallment,
			PaymentDate:    paymentDate,
			Method:         req.PaymentMethod,
		}
		if err := tx.Create(&payment).Error; err != nil {
			return err
		}

		// Keep the legacy product stock counters in sync. Purchase and
		// vendor-invoice records are static; sold quantity is tracked by the
		// sale_items rows.
		if err := consumeSaleStock(tx, companyID, req.Items); err != nil {
			return err
		}
		return nil
	})
	if err != nil {
		utils.ErrorResponse(c, 500, "Failed to record installment sale", err.Error())
		return
	}

	utils.CreatedResponse(c, "Installment sale recorded", gin.H{
		"sale":        sale,
		"installment": "first installment paid",
	})
}

// GetSubscriberInstallment returns the installment record for a subscriber,
// optionally filtered by saleId. Includes the original sale items.
func GetSubscriberInstallment(c *gin.Context) {
	companyID := c.MustGet("companyID").(uuid.UUID)
	subscriberID := c.Param("subscriberId")
	saleID := c.Query("saleId")

	var inst models.SubscriberInstallment
	query := config.DB.Where("subscriber_id = ? AND company_id = ?", subscriberID, companyID)

	if saleID != "" {
		// When saleId is provided, find the exact installment for this sale (any status)
		query = query.Where("sale_id = ?", saleID)
	} else {
		// Default: return active installment first, then completed
		query = query.Where("status IN ?", []string{"active", "completed"})
	}

	if err := query.Order("CASE WHEN status = 'active' THEN 0 ELSE 1 END").First(&inst).Error; err != nil {
		utils.ErrorResponse(c, 404, "No installment found", err.Error())
		return
	}

	// Fetch the original sale with its items
	var sale models.Sale
	var saleItems []models.SaleItem
	config.DB.Where("id = ? AND company_id = ?", inst.SaleID, companyID).First(&sale)
	config.DB.Where("sale_id = ?", inst.SaleID).Find(&saleItems)

	utils.SuccessResponse(c, "Installment found", gin.H{
		"installment": inst,
		"sale":        sale,
		"saleItems":   saleItems,
	})
}

// PayInstallment records a payment against the next installment for a subscriber.
func PayInstallment(c *gin.Context) {
	companyID := c.MustGet("companyID").(uuid.UUID)
	id := c.Param("id")

	var req struct {
		Amount float64 `json:"amount"`
		Date   string  `json:"date"`
		Method string  `json:"method"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.ErrorResponse(c, 400, "Invalid input data", err.Error())
		return
	}

	var inst models.SubscriberInstallment
	if err := config.DB.
		Where("id = ? AND company_id = ?", id, companyID).
		First(&inst).Error; err != nil {
		utils.ErrorResponse(c, 404, "Installment not found", err.Error())
		return
	}

	if inst.Status != "active" {
		utils.ErrorResponse(c, 400, "Installment is not active", "status: "+inst.Status)
		return
	}

	if inst.PaidInstallments >= inst.TotalInstallments {
		utils.ErrorResponse(c, 400, "All installments already paid", "fully paid")
		return
	}

	err := config.DB.Transaction(func(tx *gorm.DB) error {
		inst.PaidInstallments++
		inst.NextInstallment = inst.PaidInstallments + 1
		if inst.PaidInstallments >= inst.TotalInstallments {
			inst.Status = "completed"
		}
		if err := tx.Save(&inst).Error; err != nil {
			return err
		}

		// Create a Payment record so installment payments appear in dashboard collections
		paymentDate := req.Date
		if paymentDate == "" {
			paymentDate = time.Now().Format("2006-01-02")
		}
		payment := models.Payment{
			TenantModel:    models.TenantModel{CompanyID: companyID},
			SubscriberID:   &inst.SubscriberID,
			SubscriberName: inst.SubscriberName,
			Amount:         req.Amount,
			PaymentDate:    paymentDate,
			Method:         req.Method,
		}
		return tx.Create(&payment).Error
	})
	if err != nil {
		utils.ErrorResponse(c, 500, "Failed to record installment payment", err.Error())
		return
	}

	utils.SuccessResponse(c, "Installment payment recorded", inst)
}

// applyPOSSalesFilters builds the WHERE conditions shared by the count, sum
// and list queries of GetPOSSales. Always call it on a fresh *gorm.DB so the
// conditions do not leak between the Count/Scan/Find calls. Query params:
//   - fromDate / toDate   (YYYY-MM-DD, inclusive on sales.date)
//   - salesType           (good | bad | replaced)
//   - paymentType         (normal | installment | hold | promise)
//   - serviceType         (pos | fiber_jointing)
//   - paymentStatus       (paid | partial | promise | unpaid)
//   - promise             (open = only promise sales still owing money)
//   - search              (sale id, customer name, product name or SN)
func applyPOSSalesFilters(db *gorm.DB, c *gin.Context, companyID uuid.UUID) *gorm.DB {
	db = db.Scopes(models.TenantScope(companyID))

	if fromDate := strings.TrimSpace(c.Query("fromDate")); fromDate != "" {
		db = db.Where("LEFT(sales.date, 10) >= ?", fromDate)
	}
	if toDate := strings.TrimSpace(c.Query("toDate")); toDate != "" {
		db = db.Where("LEFT(sales.date, 10) <= ?", toDate)
	}

	switch salesType := strings.ToLower(strings.TrimSpace(c.Query("salesType"))); salesType {
	case "good":
		db = db.Where("EXISTS (SELECT 1 FROM sale_items si WHERE si.sale_id = sales.id AND si.original_price > 0 AND si.price > si.original_price)")
	case "bad":
		db = db.Where("NOT EXISTS (SELECT 1 FROM sale_items si WHERE si.sale_id = sales.id AND si.original_price > 0 AND si.price > si.original_price)")
	case "replaced":
		db = db.Where("sales.status = ?", "replaced")
	}

	promiseFilter := strings.ToLower(strings.TrimSpace(c.Query("promise")))
	if promiseFilter == "open" || promiseFilter == "pending" {
		db = db.Where(`sales.promise_payment = ?
			OR EXISTS (SELECT 1 FROM pos_promises pp
			           WHERE pp.company_id = sales.company_id AND pp.subscriber_id = sales.subscriber_id
			             AND pp.status IN ('pending','partial') AND pp.deleted_at IS NULL)`, true)
	}

	switch paymentType := strings.ToLower(strings.TrimSpace(c.Query("paymentType"))); paymentType {
	case "hold":
		db = db.Where("sales.status = ?", "hold")
	case "promise":
		// Any sale related to a promise: the original product sale, or a dues
		// payment row created when the counter took money against it.
		db = db.Where(`sales.promise_payment = ?
			OR EXISTS (SELECT 1 FROM pos_promises pp
			           WHERE pp.sale_id = sales.id AND pp.company_id = sales.company_id AND pp.deleted_at IS NULL)`, true)
	case "normal":
		db = db.Where("sales.is_installment = ?", false)
	case "installment":
		db = db.Where("sales.is_installment = ?", true)
	}

	// One-time service types (fiber jointing / cable repair) are recorded as
	// sales rows tagged with sale_type, separate from the monthly POS flow.
	switch serviceType := strings.ToLower(strings.TrimSpace(c.Query("serviceType"))); serviceType {
	case "fiber_jointing", "fiberjointing":
		db = db.Where("sales.sale_type = ?", models.SaleTypeFiberJointing)
	case "pos", "product":
		db = db.Where("sales.sale_type IS NULL OR sales.sale_type = ?", models.SaleTypePOS)
	}

	// Payment status of the sale's own money, for service-charge rows: paid,
	// partial, promise, unpaid.
	switch paymentStatus := strings.ToLower(strings.TrimSpace(c.Query("paymentStatus"))); paymentStatus {
	case "paid", "partial", "promise", "unpaid":
		db = db.Where("sales.payment_status = ?", paymentStatus)
	}

	// OLD search (before product-name search) — kept for easy rollback:
	// if q := strings.TrimSpace(c.Query("search")); q != "" {
	// 	like := strings.ToLower(q) + "%"
	// 	db = db.Where("LOWER(sales.subscriber_name) LIKE ? OR LOWER(sales.id::text) LIKE ?", like, like)
	// }

	// Search matches the customer name, the sale ID, or the name / SN of any
	// product sold in the sale. Done in SQL so the frontend only receives the
	// matching page of rows.
	if q := strings.TrimSpace(c.Query("search")); q != "" {
		like := "%" + strings.ToLower(q) + "%"
		db = db.Where(`LOWER(sales.subscriber_name) LIKE ?
			OR LOWER(sales.id::text) LIKE ?
			OR EXISTS (SELECT 1 FROM sale_items si
			           WHERE si.sale_id = sales.id AND si.deleted_at IS NULL
			             AND (LOWER(si.product_name) LIKE ? OR LOWER(si.serial_number) LIKE ?))`,
			like, like, like, like)
	}

	return db
}

// GetPOSSales lists POS sales with optional filters.
//
// Without a "page" query param it returns the full filtered list as a plain
// array (used by reports, the replaced page and the mobile app).
// With "page" (and optional "pageSize": number or "all") it returns one page
// plus totals for the whole filtered set:
//
//	{ sales: [...], total, totalRevenue, page, pageSize }
func GetPOSSales(c *gin.Context) {
	companyID := c.MustGet("companyID").(uuid.UUID)

	// OLD body (before backend pagination) — kept for easy rollback. The
	// filters now live in applyPOSSalesFilters above:
	// db := config.DB.Scopes(models.TenantScope(companyID))
	// ... filters ...
	// var sales []models.Sale
	// if err := db.Preload("Items").Order("created_at DESC").Find(&sales).Error; err != nil {
	// 	utils.ErrorResponse(c, 500, "Failed to fetch sales", err.Error())
	// 	return
	// }
	// attachPromiseInfo(companyID, sales)
	// utils.SuccessResponse(c, "Records retrieved", sales)

	pageParam := strings.TrimSpace(c.Query("page"))
	if pageParam == "" {
		var sales []models.Sale
		if err := applyPOSSalesFilters(config.DB.Model(&models.Sale{}), c, companyID).
			Preload("Items").Order("created_at DESC").Find(&sales).Error; err != nil {
			utils.ErrorResponse(c, 500, "Failed to fetch sales", err.Error())
			return
		}
		// Attach the unpaid part of any promise sale so the list can mark it as
		// pending instead of presenting a partly unpaid sale as fully paid.
		attachPromiseInfo(companyID, sales)
		utils.SuccessResponse(c, "Records retrieved", sales)
		return
	}

	page, _ := strconv.Atoi(pageParam)
	if page < 1 {
		page = 1
	}
	pageSizeParam := strings.TrimSpace(c.DefaultQuery("pageSize", "10"))

	var total int64
	if err := applyPOSSalesFilters(config.DB.Model(&models.Sale{}), c, companyID).
		Count(&total).Error; err != nil {
		utils.ErrorResponse(c, 500, "Failed to count sales", err.Error())
		return
	}

	var sumRow struct{ Total float64 }
	if err := applyPOSSalesFilters(config.DB.Model(&models.Sale{}), c, companyID).
		Select("COALESCE(SUM(sales.total_amount), 0) AS total").
		Scan(&sumRow).Error; err != nil {
		utils.ErrorResponse(c, 500, "Failed to sum sales", err.Error())
		return
	}

	query := applyPOSSalesFilters(config.DB.Model(&models.Sale{}), c, companyID).
		Preload("Items").Order("created_at DESC")
	if pageSizeParam != "all" {
		pageSize, err := strconv.Atoi(pageSizeParam)
		if err != nil || pageSize < 1 {
			pageSize = 10
			pageSizeParam = "10"
		}
		query = query.Limit(pageSize).Offset((page - 1) * pageSize)
	}

	var sales []models.Sale
	if err := query.Find(&sales).Error; err != nil {
		utils.ErrorResponse(c, 500, "Failed to fetch sales", err.Error())
		return
	}
	attachPromiseInfo(companyID, sales)

	utils.SuccessResponse(c, "Records retrieved", gin.H{
		"sales":        sales,
		"total":        total,
		"totalRevenue": sumRow.Total,
		"page":         page,
		"pageSize":     pageSizeParam,
	})
}

// attachPromiseInfo fills Sale.PromiseInfo in one or two queries, rather than one
// lookup per row. Promise sales read their linked promise; dues-payment sales
// read the customer's live open balance so they always stay in step with what is
// still actually owing.
func attachPromiseInfo(companyID uuid.UUID, sales []models.Sale) {
	if len(sales) == 0 {
		return
	}

	var saleIDs []uuid.UUID
	paymentSubscribers := make(map[uuid.UUID]struct{}, len(sales))
	for i := range sales {
		if sales[i].PromisePayment {
			paymentSubscribers[sales[i].SubscriberID] = struct{}{}
		} else {
			saleIDs = append(saleIDs, sales[i].ID)
		}
	}

	index := make(map[uuid.UUID]*models.Sale, len(sales))
	for i := range sales {
		index[sales[i].ID] = &sales[i]
	}

	var promises []models.POSPromise
	if len(saleIDs) > 0 {
		if err := config.DB.Where("company_id = ? AND sale_id IN ?", companyID, saleIDs).Find(&promises).Error; err != nil {
			log.Printf("attachPromiseInfo: %v", err)
		}
	}
	for _, p := range promises {
		sale, ok := index[p.SaleID]
		if !ok {
			continue
		}
		sale.PromiseInfo = &models.SalePromiseInfo{
			PromiseID:       p.ID.String(),
			PendingAmount:   p.PendingAmount,
			PaidAmount:      p.PaidAmount,
			CollectedAmount: p.CollectedAmount,
			RemainingAmount: posPromiseRemaining(p),
			PromiseDate:     p.PromiseDate,
			Status:          p.Status,
			Description:     p.Description,
		}
	}

	if len(paymentSubscribers) == 0 {
		return
	}
	subscriberIDs := make([]uuid.UUID, 0, len(paymentSubscribers))
	for id := range paymentSubscribers {
		subscriberIDs = append(subscriberIDs, id)
	}

	var open []models.POSPromise
	if err := config.DB.Where("company_id = ? AND subscriber_id IN ? AND status IN ?",
		companyID, subscriberIDs, []string{"pending", "partial"}).Find(&open).Error; err != nil {
		log.Printf("attachPromiseInfo: %v", err)
		return
	}

	bySubscriber := make(map[uuid.UUID]float64, len(subscriberIDs))
	for _, p := range open {
		bySubscriber[p.SubscriberID] = roundPOSMoney(bySubscriber[p.SubscriberID] + posPromiseRemaining(p))
	}

	for i := range sales {
		sale := &sales[i]
		if !sale.PromisePayment {
			continue
		}
		remaining := bySubscriber[sale.SubscriberID]
		status := "partial"
		if remaining <= 0 {
			status = "completed"
		}
		sale.PromiseInfo = &models.SalePromiseInfo{
			PendingAmount:   roundPOSMoney(remaining + sale.TotalAmount),
			PaidAmount:      sale.TotalAmount,
			CollectedAmount: sale.TotalAmount,
			RemainingAmount: remaining,
			PromiseDate:     sale.Date,
			Status:          status,
			Description:     "Counter dues payment",
		}
	}
}

// GetPOSSale returns a single sale (with items) by id.
func GetPOSSale(c *gin.Context) {
	companyID := c.MustGet("companyID").(uuid.UUID)
	id := c.Param("id")

	var sale models.Sale
	if err := config.DB.
		Scopes(models.TenantScope(companyID)).
		Preload("Items").
		Where("id = ?", id).
		First(&sale).Error; err != nil {
		utils.ErrorResponse(c, 404, "Sale not found", err.Error())
		return
	}

	utils.SuccessResponse(c, "Record found", sale)
}

// DeletePOSSale deletes a sale and its line items (cascaded). A held (unpaid)
// sale had reserved inventory from the point of sale, so deleting one restores
// the SNs and quantities it consumed. Completed/paid sales are permanent and
// are removed without side effects.
func DeletePOSSale(c *gin.Context) {
	companyID := c.MustGet("companyID").(uuid.UUID)
	id := c.Param("id")

	var sale models.Sale
	if err := config.DB.
		Scopes(models.TenantScope(companyID)).
		Preload("Items").
		Where("id = ?", id).
		First(&sale).Error; err != nil {
		utils.ErrorResponse(c, 404, "Sale not found", err.Error())
		return
	}

	if sale.Status == "hold" {
		err := config.DB.Transaction(func(tx *gorm.DB) error {
			if err := revertSaleStock(tx, companyID, sale); err != nil {
				return err
			}
			return tx.Delete(&sale).Error
		})
		if err != nil {
			utils.ErrorResponse(c, 500, "Failed to delete held sale", err.Error())
			return
		}
		utils.SuccessResponse(c, "Held sale deleted, stock restored", nil)
		return
	}

	if err := config.DB.Delete(&sale).Error; err != nil {
		utils.ErrorResponse(c, 500, "Failed to delete sale", err.Error())
		return
	}

	utils.SuccessResponse(c, "Sale deleted successfully", nil)
}

// ReturnPOSSale marks a completed, non-installment sale as returned and
// restores every sold item/SN back to inventory (purchase items, product stock
// and serial lists) so the goods can be sold again. The original sale record is
// kept for history and flagged with status "returned".
func ReturnPOSSale(c *gin.Context) {
	companyID := c.MustGet("companyID").(uuid.UUID)
	id := c.Param("id")

	var sale models.Sale
	if err := config.DB.
		Scopes(models.TenantScope(companyID)).
		Preload("Items").
		Where("id = ?", id).
		First(&sale).Error; err != nil {
		utils.ErrorResponse(c, 404, "Sale not found", err.Error())
		return
	}

	if sale.Status == "returned" {
		utils.ErrorResponse(c, 400, "Sale already returned", "This sale has already been returned.")
		return
	}
	if sale.Status == "hold" {
		utils.ErrorResponse(c, 400, "Hold bill cannot be returned", "Delete the hold bill instead to restore its stock.")
		return
	}
	if sale.IsInstallment {
		utils.ErrorResponse(c, 400, "Installment sale cannot be returned", "Installment sales must be managed through their installment plan.")
		return
	}

	err := config.DB.Transaction(func(tx *gorm.DB) error {
		if err := revertSaleStock(tx, companyID, sale); err != nil {
			return err
		}
		return tx.Model(&models.Sale{}).
			Where("id = ?", sale.ID).
			Update("status", "returned").Error
	})
	if err != nil {
		utils.ErrorResponse(c, 500, "Failed to return sale", err.Error())
		return
	}

	sale.Status = "returned"
	utils.SuccessResponse(c, "Sale returned successfully, stock restored", sale)
}

// ReplacePOSSale replaces a completed, non-installment sale with a new product.
// It works like a return-plus-new-sale executed atomically in a single
// transaction: the old sale's stock is restored (revertSaleStock), the old sale
// is marked as "replaced", and a brand new sale is created for the replacement
// product (its stock being consumed via the normal POS sale path). The new sale
// is itself labelled "replaced" so it can be distinguished from regular sales.
func ReplacePOSSale(c *gin.Context) {
	companyID := c.MustGet("companyID").(uuid.UUID)
	id := c.Param("id")

	var req posSaleRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.ErrorResponse(c, 400, "Invalid input data", err.Error())
		return
	}
	if len(req.Items) == 0 {
		utils.ErrorResponse(c, 400, "Replacement must contain at least one item", "no items")
		return
	}

	var sale models.Sale
	if err := config.DB.
		Scopes(models.TenantScope(companyID)).
		Preload("Items").
		Where("id = ?", id).
		First(&sale).Error; err != nil {
		utils.ErrorResponse(c, 404, "Sale not found", err.Error())
		return
	}

	if sale.Status == "returned" {
		utils.ErrorResponse(c, 400, "Sale already returned", "This sale has already been returned.")
		return
	}
	if sale.Status == "replaced" {
		utils.ErrorResponse(c, 400, "Sale already replaced", "This sale has already been replaced.")
		return
	}
	if sale.Status == "hold" {
		utils.ErrorResponse(c, 400, "Hold bill cannot be replaced", "Delete the hold bill instead to restore its stock.")
		return
	}
	if sale.IsInstallment {
		utils.ErrorResponse(c, 400, "Installment sale cannot be replaced", "Installment sales must be managed through their installment plan.")
		return
	}

	// Build the replacement items (installed onto the existing sale row).
	replacementItems := make([]models.SaleItem, 0, len(req.Items))
	for _, it := range req.Items {
		replacementItems = append(replacementItems, models.SaleItem{
			ProductID:     it.ProductID,
			ProductName:   it.ProductName,
			Quantity:      it.Quantity,
			Price:         it.Price,
			OriginalPrice: it.OriginalPrice,
			TaxPercent:    it.TaxPercent,
			SaleTax:       it.SaleTax,
			WthTax:        it.WthTax,
			SerialNumber:  it.SerialNumber,
			Model:         it.Model,
		})
	}

	// Snapshot the ORIGINAL sale (items + totals) so the replaced page can show
	// what the entry looked like before the replacement.
	originalSnapshot := struct {
		TotalAmount   float64           `json:"totalAmount"`
		TaxAmount     float64           `json:"taxAmount"`
		PaymentMethod string            `json:"paymentMethod"`
		Date          string            `json:"date"`
		Discount      float64           `json:"discount"`
		Items         []models.SaleItem `json:"items"`
	}{
		TotalAmount:   sale.TotalAmount,
		TaxAmount:     sale.TaxAmount,
		PaymentMethod: sale.PaymentMethod,
		Date:          sale.Date,
		Discount:      sale.Discount,
		Items:         sale.Items,
	}
	snapshotBytes, err := json.Marshal(originalSnapshot)
	if err != nil {
		utils.ErrorResponse(c, 500, "Failed to snapshot original sale", err.Error())
		return
	}

	err = config.DB.Transaction(func(tx *gorm.DB) error {
		// Restore the replaced product's stock (same as a full return).
		if err := revertSaleStock(tx, companyID, sale); err != nil {
			return err
		}
		// Consume the new product's stock (same as a fresh POS sale).
		if err := consumeSaleStock(tx, companyID, req.Items); err != nil {
			return err
		}
		// Delete the original sale items, then attach the replacement items.
		if err := tx.Where("sale_id = ?", sale.ID).Delete(&models.SaleItem{}).Error; err != nil {
			return err
		}
		for i := range replacementItems {
			replacementItems[i].SaleID = sale.ID
		}
		if err := tx.Create(&replacementItems).Error; err != nil {
			return err
		}
		// Overwrite the existing sale with the replacement details + mark replaced.
		updates := map[string]interface{}{
			"subscriber_name": req.SubscriberName,
			"total_amount":    req.TotalAmount,
			"tax_amount":      req.TaxAmount,
			"discount":        req.Discount,
			"payment_method":  req.PaymentMethod,
			"date":            req.Date,
			"is_installment":  false,
			"status":          "replaced",
			"replaced_from":   string(snapshotBytes),
		}
		if err := tx.Model(&models.Sale{}).Scopes(models.TenantScope(companyID)).Where("id = ?", sale.ID).Updates(updates).Error; err != nil {
			return err
		}
		return nil
	})
	if err != nil {
		utils.ErrorResponse(c, 500, "Failed to replace sale", err.Error())
		return
	}

	// Reload the replaced sale with its new items for the response.
	if err := config.DB.Scopes(models.TenantScope(companyID)).Preload("Items").Where("id = ?", sale.ID).First(&sale).Error; err != nil {
		utils.ErrorResponse(c, 500, "Failed to load replaced sale", err.Error())
		return
	}

	utils.CreatedResponse(c, "Sale replaced successfully", gin.H{
		"sale": sale,
	})
}

// revertSaleStock returns a held sale's items back to inventory. It restores
// each sold SN to the purchase items that drive the point-of-sale list and, if
// the SN was consumed from the product record itself (legacy path), back to
// the product's serial list / stock as well. Serial-less (quantity-based)
// products have their quantities added back to the purchase items and product
// stock.
func revertSaleStock(tx *gorm.DB, companyID uuid.UUID, sale models.Sale) error {
	for _, it := range sale.Items {
		qty := it.Quantity
		if qty <= 0 {
			continue
		}
		soldSNs := parsePOSsoldSNs(it.SerialNumber, qty)
		if len(soldSNs) == 0 {
			if err := restoreQuantityStock(tx, companyID, it.ProductID, qty); err != nil {
				return err
			}
			continue
		}
		if err := restoreSNsToPurchaseItems(tx, companyID, it.ProductID, soldSNs); err != nil {
			return err
		}
		if err := restoreProductSerialNumbers(tx, companyID, it.ProductID, soldSNs); err != nil {
			return err
		}
	}
	return nil
}

// restoreQuantityStock returns the sold quantity of a serial-less (measured)
// product to the point-of-sale stock. It reverses the quantity-based
// consumption that ran when the sale was created: the quantity is added back to
// the most-depleted purchase item of the product (the consume path took it from
// the most-stocked one, so this restores the total) and the product's stock is
// incremented to keep the inventory status page in sync.
func restoreQuantityStock(tx *gorm.DB, companyID, productID uuid.UUID, qty int) error {
	if qty <= 0 {
		return nil
	}

	var item models.PurchaseItem
	err := tx.Where("company_id = ? AND product_id = ? AND deleted_at IS NULL", companyID, productID).
		Order("quantity asc, created_at asc").
		First(&item).Error
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			return nil
		}
		return err
	}

	if err := tx.Model(&models.PurchaseItem{}).
		Where("id = ?", item.ID).
		Update("quantity", gorm.Expr("quantity + ?", qty)).Error; err != nil {
		return err
	}

	return tx.Model(&models.Product{}).
		Where("id = ? AND company_id = ?", productID, companyID).
		Update("stock", gorm.Expr("COALESCE(stock, 0) + ?", qty)).Error
}

// restoreSNsToPurchaseItems returns serial numbers to the purchase items of a
// product. SNs no longer held anywhere are appended to the oldest SN-bearing
// purchase item, and every SN-bearing item then has its quantity/subtotal
// recomputed from its serial list so POS availability returns to its
// pre-sale state. Quantity-only (no SN) items are left untouched.
func restoreSNsToPurchaseItems(tx *gorm.DB, companyID, productID uuid.UUID, sns []string) error {
	if len(sns) == 0 {
		return nil
	}

	var items []models.PurchaseItem
	if err := tx.Where("company_id = ? AND product_id = ? AND deleted_at IS NULL", companyID, productID).
		Order("created_at asc").
		Find(&items).Error; err != nil {
		return err
	}
	if len(items) == 0 {
		return nil
	}

	var target *models.PurchaseItem
	for i := range items {
		if len(parseVendorInvoiceSNs(items[i].SerialNumber)) > 0 {
			target = &items[i]
			break
		}
	}
	if target == nil {
		target = &items[0]
	}

	have := make(map[string]bool)
	for _, sn := range parseVendorInvoiceSNs(target.SerialNumber) {
		have[sn] = true
	}
	var toAdd []string
	for _, sn := range sns {
		if !have[sn] {
			toAdd = append(toAdd, sn)
		}
	}
	if len(toAdd) > 0 {
		target.SerialNumber = strings.TrimSpace(target.SerialNumber + ", " + strings.Join(toAdd, ", "))
	}

	for i := range items {
		serials := parseVendorInvoiceSNs(items[i].SerialNumber)
		if len(serials) == 0 {
			continue
		}
		newQty := len(serials)
		if err := tx.Model(&models.PurchaseItem{}).
			Where("id = ?", items[i].ID).
			Updates(map[string]interface{}{
				"serial_number": strings.Join(serials, ", "),
				"quantity":      newQty,
				"subtotal":      items[i].PurchasePrice * float64(newQty),
			}).Error; err != nil {
			return err
		}
	}
	return nil
}

// restoreProductSerialNumbers returns consumed serial numbers to the product
// record (legacy path where SNs were removed directly from the product's
// serial list). SNs that are still present are left untouched, so serial lists
// consumed from purchase items are not doubled up.
func restoreProductSerialNumbers(tx *gorm.DB, companyID, productID uuid.UUID, sns []string) error {
	if len(sns) == 0 {
		return nil
	}

	var prod models.Product
	if err := tx.Where("id = ? AND company_id = ?", productID, companyID).First(&prod).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			return nil
		}
		return err
	}

	allSNs := prod.ParseSerialNumbers()
	have := make(map[string]bool, len(allSNs))
	for _, sn := range allSNs {
		have[sn] = true
	}
	var toAdd []string
	for _, sn := range sns {
		if !have[sn] {
			toAdd = append(toAdd, sn)
		}
	}
	if len(toAdd) == 0 {
		return nil
	}

	merged := append(allSNs, toAdd...)
	return tx.Model(&models.Product{}).
		Where("id = ? AND company_id = ?", productID, companyID).
		Updates(map[string]interface{}{
			"serial_number": strings.Join(merged, ", "),
			"stock":         len(merged),
		}).Error
}

type posSaleStatusRequest struct {
	Status        string `json:"status" binding:"required"`
	PaymentMethod string `json:"paymentMethod"`
}

// UpdatePOSSaleStatus updates a sale's status (and optionally payment method).
// Used to settle a held bill: once a hold is paid the sale becomes permanent
// and no longer restores stock if deleted.
func UpdatePOSSaleStatus(c *gin.Context) {
	companyID := c.MustGet("companyID").(uuid.UUID)
	id := c.Param("id")

	var req posSaleStatusRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.ErrorResponse(c, 400, "Invalid input data", err.Error())
		return
	}

	var sale models.Sale
	if err := config.DB.
		Scopes(models.TenantScope(companyID)).
		Where("id = ?", id).
		First(&sale).Error; err != nil {
		utils.ErrorResponse(c, 404, "Sale not found", err.Error())
		return
	}

	updates := map[string]interface{}{"status": req.Status}
	if req.PaymentMethod != "" {
		updates["payment_method"] = req.PaymentMethod
	}
	if err := config.DB.Model(&sale).Updates(updates).Error; err != nil {
		utils.ErrorResponse(c, 500, "Failed to update sale status", err.Error())
		return
	}

	utils.SuccessResponse(c, "Sale status updated", gin.H{"status": req.Status})
}
