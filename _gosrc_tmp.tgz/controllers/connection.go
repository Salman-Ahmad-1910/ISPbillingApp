package controllers

import (
	"awesomeProject/config"
	"awesomeProject/models"
	"awesomeProject/utils"
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

func decrementSplitterPorts(tx *gorm.DB, splitterID string) error {
	var splitter models.Splitter
	if err := tx.First(&splitter, "id = ?", splitterID).Error; err != nil {
		return fmt.Errorf("splitter not found")
	}
	if splitter.AvailablePorts <= 0 {
		return fmt.Errorf("no available ports on splitter %s", splitter.Name)
	}
	return tx.Model(&models.Splitter{}).Where("id = ?", splitterID).
		UpdateColumn("available_ports", gorm.Expr("GREATEST(available_ports - 1, 0)")).Error
}

func incrementSplitterPorts(tx *gorm.DB, splitterID string) error {
	var splitter models.Splitter
	if err := tx.First(&splitter, "id = ?", splitterID).Error; err != nil {
		return nil
	}
	return tx.Model(&models.Splitter{}).Where("id = ?", splitterID).
		UpdateColumn("available_ports", gorm.Expr("LEAST(available_ports + 1, total_ports)")).Error
}

func RegisterConnectionRoutes(admin *gin.RouterGroup) {
	connections := admin.Group("/connections")
	connections.GET("", findConnections)
	connections.GET("/logs", getConnectionLogs)
	connections.POST("", createConnection)
	connections.POST("/bulk-sublocality", bulkUpdateConnectionSublocality)
	connections.PUT("/:id", updateConnection)
	connections.DELETE("/:id", deleteConnection)
}

// bulkSublocalityRequest holds the ids and target sublocality for a bulk
// area assignment performed from the subscriber list.
type bulkSublocalityRequest struct {
	IDs           []string `json:"ids"`
	SublocalityID string   `json:"sublocalityId"`
	Reason        string   `json:"reason"`
	Comments      string   `json:"comments"`
}

// bulkUpdateConnectionSublocality assigns the given sublocality (Area UUID) to
// all selected subscriptions of the current company. Subscribers assigned to an
// area then show up for the recovery officers assigned to that area.
func bulkUpdateConnectionSublocality(c *gin.Context) {
	companyID := c.MustGet("companyID").(uuid.UUID)

	var req bulkSublocalityRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.ErrorResponse(c, 400, "Invalid input data", err.Error())
		return
	}

	ids := make([]string, 0, len(req.IDs))
	for _, id := range req.IDs {
		if id != "" {
			ids = append(ids, id)
		}
	}
	if len(ids) == 0 {
		utils.ErrorResponse(c, 400, "At least one subscriber id is required", nil)
		return
	}

	areaUUID, err := uuid.Parse(req.SublocalityID)
	if err != nil {
		utils.ErrorResponse(c, 400, "Invalid sublocality id", err.Error())
		return
	}

	var area models.Area
	if err := config.DB.Scopes(models.TenantScope(companyID)).First(&area, "id = ?", areaUUID).Error; err != nil {
		utils.ErrorResponse(c, 400, "Sublocality not found", nil)
		return
	}

	var conns []models.Connection
	if err := config.DB.Scopes(models.TenantScope(companyID)).Where("id IN ?", ids).Find(&conns).Error; err != nil {
		utils.ErrorResponse(c, 500, "Failed to load subscribers", err.Error())
		return
	}

	if len(conns) == 0 {
		utils.SuccessResponse(c, "Sublocality updated", gin.H{"updated": 0, "skipped": 0})
		return
	}

	target := areaUUID.String()
	updated := 0
	skipped := 0
	for i := range conns {
		old := conns[i]
		if old.SublocalityID == target {
			skipped++
			continue
		}
		if err := config.DB.Model(&models.Connection{}).Where("id = ?", old.ID).
			Update("sublocality_id", target).Error; err != nil {
			utils.ErrorResponse(c, 500, "Failed to update subscriber", err.Error())
			return
		}
		createConnectionLogs(c, old, []connChange{{
			FieldName:  "sublocality",
			ActionType: "Area Changed",
			Old:        old.SublocalityID,
			New:        target,
		}}, req.Reason, req.Comments)
		updated++
	}

	utils.SuccessResponse(c, "Sublocality updated", gin.H{"updated": updated, "skipped": skipped})
}

func findConnections(c *gin.Context) {
	companyID := c.MustGet("companyID").(uuid.UUID)

	// One-time cleanup: fix stale advance entries where remaining >= 0
	config.DB.Model(&models.Connection{}).
		Where("company_id = ? AND deleted_at IS NULL AND payment_status = ? AND remaining_amount >= 0", companyID, "advance").
		UpdateColumns(map[string]interface{}{
			"payment_status": "",
		})

	var connections []models.Connection
	db := config.DB.Scopes(models.TenantScope(companyID))

	// Recovery officers may only see subscribers in the areas assigned to them:
	// sublocality_id stores the Area UUID as text, and each officer's areas come
	// from the area_officers join table (plus their legacy single AreaID).
	if idValue, ok := c.Get("userID"); ok {
		userID, ok := idValue.(uuid.UUID)
		if ok {
			var officer models.RecoveryOfficer
			if err := config.DB.Where("id = ? AND company_id = ?", userID, companyID).First(&officer).Error; err == nil {
				areaCond := "(sublocality_id IN (SELECT area_id::text FROM area_officers WHERE recovery_officer_id = ? AND company_id = ?)"
				args := []interface{}{userID, companyID}
				if officer.AreaID != nil {
					areaCond += " OR sublocality_id = ?"
					args = append(args, officer.AreaID.String())
				}
				areaCond += ")"
				db = db.Where(areaCond, args...)
			}
		}
	}

	queryValues := c.Request.URL.Query()
	for key, values := range queryValues {
		if key == "companyId" || key == "page" || key == "limit" {
			continue
		}
		if len(values) > 0 && values[0] != "" {
			db = db.Where(key+" = ?", values[0])
		}
	}

	if err := db.Find(&connections).Error; err != nil {
		utils.ErrorResponse(c, 500, "Failed to fetch connections", err.Error())
		return
	}

	utils.SuccessResponse(c, "Connections retrieved", connections)
}

type connectionInput struct {
	InternetID         string   `json:"internetId"`
	Name               string   `json:"name"`
	Address            string   `json:"address"`
	Cell               string   `json:"cell"`
	Mobile             string   `json:"mobile"`
	InstallationAmount float64  `json:"installationAmount"`
	OtherAmount        float64  `json:"otherAmount"`
	InstallationDate   string   `json:"installationDate"`
	RechargeDate       string   `json:"rechargeDate"`
	ConnectionProvider string   `json:"connectionProvider"`
	ConnectionType     string   `json:"connectionType"`
	BoxNumber          string   `json:"boxNumber"`
	PackageCable       string   `json:"packageCable"`
	Discount           string   `json:"discount"`
	Amount             *float64 `json:"amount"`
	PackageInternet    string   `json:"packageInternet"`
	CreateBalance      *bool    `json:"createBalance"`
	BalanceDays        int      `json:"balanceDays"`
	SameDiscount       string   `json:"sameDiscount"`
	SameAmount         *float64 `json:"sameAmount"`
	Status             string   `json:"status"`
	SublocalityID      string   `json:"sublocalityId"`
	SplitterID         string   `json:"splitterId"`
	SplitterPort       int      `json:"splitterPort"`
	LeavingDate        string   `json:"leavingDate"`
	DeactivationReason string   `json:"deactivationReason"`
	Comments           string   `json:"comments"`
	Reason             string   `json:"reason"`
	BadDebt            *bool    `json:"badDebt"`
	PaymentStatus      *string  `json:"paymentStatus"`
	RemainingAmount    *float64 `json:"remainingAmount"`
	TransactionId      string   `json:"transactionId"`
}

func createConnection(c *gin.Context) {
	companyID := c.MustGet("companyID").(uuid.UUID)

	var input connectionInput
	if err := c.ShouldBindJSON(&input); err != nil {
		utils.ErrorResponse(c, 400, "Invalid input data", err.Error())
		return
	}

	if input.InternetID == "" || input.Name == "" {
		utils.ErrorResponse(c, 400, "Internet ID and Name are required", nil)
		return
	}

	tx := config.DB.Begin()
	if tx.Error != nil {
		utils.ErrorResponse(c, 500, "Failed to start transaction", tx.Error.Error())
		return
	}

	// The partial unique index on (company_id, internet_id) covers soft-deleted
	// rows too, so re-uploading a file (e.g. the export with an updated
	// Sublocality column) used to surface a raw unique-constraint error. Check
	// for an existing row and either restore a soft-deleted one or return a
	// clean 409 so the import never leaks the database error.
	var dup models.Connection
	if err := tx.Unscoped().Where("company_id = ? AND internet_id = ?", companyID, input.InternetID).First(&dup).Error; err == nil {
		if !dup.DeletedAt.Valid {
			tx.Rollback()
			utils.ErrorResponse(c, 409, "Duplicate subscriber", fmt.Sprintf("A subscriber with Internet ID %s already exists", input.InternetID))
			return
		}

		// Only a soft-deleted row holds this ID: restore it instead of
		// re-creating (which would violate the unique index).
		restore := map[string]interface{}{
			"deleted_at":     nil,
			"name":           input.Name,
			"address":        input.Address,
			"cell":           input.Cell,
			"mobile":         input.Mobile,
			"status":         input.Status,
			"sublocality_id": input.SublocalityID,
		}
		if err := tx.Model(&models.Connection{}).Unscoped().Where("id = ? AND company_id = ?", dup.ID, companyID).Updates(restore).Error; err != nil {
			tx.Rollback()
			utils.ErrorResponse(c, 500, "Failed to restore subscriber", err.Error())
			return
		}
		if err := tx.Commit().Error; err != nil {
			utils.ErrorResponse(c, 500, "Failed to commit", err.Error())
			return
		}
		utils.CreatedResponse(c, "Connection restored", dup)
		return
	}

	if input.SplitterID != "" {
		if _, err := uuid.Parse(input.SplitterID); err != nil {
			tx.Rollback()
			utils.ErrorResponse(c, 400, "Invalid splitter ID", err.Error())
			return
		}
		if err := decrementSplitterPorts(tx, input.SplitterID); err != nil {
			tx.Rollback()
			utils.ErrorResponse(c, 400, "Splitter port error", err.Error())
			return
		}
	}

	// The connection type decides which package columns are in use. Normalise
	// them here for the same reason as an edit: a stale package on the other
	// side would otherwise be stored and displayed next to the new package.
	packageCable, packageInternet := packagesForType(input.ConnectionType, input.PackageCable, input.PackageInternet)

	conn := models.Connection{
		InternetID:         input.InternetID,
		Name:               input.Name,
		Address:            input.Address,
		Cell:               input.Cell,
		Mobile:             input.Mobile,
		InstallationAmount: input.InstallationAmount,
		OtherAmount:        input.OtherAmount,
		InstallationDate:   input.InstallationDate,
		RechargeDate:       input.RechargeDate,
		ConnectionProvider: input.ConnectionProvider,
		ConnectionType:     input.ConnectionType,
		BoxNumber:          input.BoxNumber,
		PackageCable:       packageCable,
		Discount:           input.Discount,
		Amount:             valueOrZero(input.Amount),
		PackageInternet:    packageInternet,
		CreateBalance:      input.CreateBalance != nil && *input.CreateBalance,
		BalanceDays:        input.BalanceDays,
		SameDiscount:       input.SameDiscount,
		SameAmount:         valueOrZero(input.SameAmount),
		Status:             input.Status,
		SublocalityID:      input.SublocalityID,
		SplitterID:         input.SplitterID,
		SplitterPort:       input.SplitterPort,
		TransactionId:      input.TransactionId,
	}

	// A new subscriber starts with no balance. If the "Create balance" option
	// is enabled, an opening balance equal to the package fee prorated for the
	// remaining days of the month is created (fee / 30 * days).
	conn.RemainingAmount = 0
	if input.CreateBalance != nil && *input.CreateBalance && input.BalanceDays > 0 {
		cableFee := valueOrZero(input.Amount)
		internetFee := valueOrZero(input.SameAmount)
		fee := cableFee
		switch input.ConnectionType {
		case "internet":
			fee = internetFee
		case "both":
			fee = cableFee + internetFee
		}
		conn.RemainingAmount = roundToTwo(fee / 30 * float64(input.BalanceDays))
	}
	conn.CompanyID = companyID

	// Track which staff member created this subscriber
	if userID, exists := c.Get("userID"); exists {
		if uid, ok := userID.(uuid.UUID); ok {
			conn.CreatedBy = &uid
		}
	}

	if err := tx.Create(&conn).Error; err != nil {
		tx.Rollback()
		utils.ErrorResponse(c, 500, "Failed to create connection", err.Error())
		return
	}

	if err := tx.Commit().Error; err != nil {
		utils.ErrorResponse(c, 500, "Failed to commit", err.Error())
		return
	}

	createConnectionLogs(c, conn, []connChange{{
		FieldName:  "connection",
		ActionType: "New Connection Installed",
		Old:        "",
		New:        fmt.Sprintf("%s (%s)", conn.Name, conn.InternetID),
	}}, input.Reason, input.Comments)

	utils.CreatedResponse(c, "Connection created", conn)
}

func updateConnection(c *gin.Context) {
	id := c.Param("id")

	var input connectionInput
	if err := c.ShouldBindJSON(&input); err != nil {
		utils.ErrorResponse(c, 400, "Invalid input data", err.Error())
		return
	}

	// Package fees are the basis of every proration calculation, so they are
	// validated on the backend rather than trusted from the client.
	if input.Amount != nil && *input.Amount < 0 {
		utils.ErrorResponse(c, 400, "Cable package fee cannot be negative", nil)
		return
	}
	if input.SameAmount != nil && *input.SameAmount < 0 {
		utils.ErrorResponse(c, 400, "Internet package fee cannot be negative", nil)
		return
	}
	if input.RemainingAmount != nil && math.IsNaN(*input.RemainingAmount) {
		utils.ErrorResponse(c, 400, "Remaining amount is not a valid number", nil)
		return
	}

	// Set when the update carries a manually created balance, so the amount is
	// recorded in the connection history alongside field edits.
	var balanceChange *connChange

	tx := config.DB.Begin()
	if tx.Error != nil {
		utils.ErrorResponse(c, 500, "Failed to start transaction", tx.Error.Error())
		return
	}
	// Safety net for the error paths that return without an explicit rollback.
	defer tx.Rollback()

	// SELECT ... FOR UPDATE. The proration delta is derived from the fee read
	// here, so two concurrent submissions of the same upgrade could otherwise
	// both read the old fee and each add the difference, charging twice. The
	// row lock makes the second request wait and then observe the already
	// updated fee, which makes the adjustment a no-op instead of a duplicate.
	var old models.Connection
	if err := tx.Clauses(clause.Locking{Strength: "UPDATE"}).
		First(&old, "id = ?", id).Error; err != nil {
		tx.Rollback()
		utils.ErrorResponse(c, 404, "Connection not found", nil)
		return
	}

	// Build partial update map
	updates := map[string]interface{}{}

	if input.InternetID != "" {
		updates["internet_id"] = input.InternetID
	}
	if input.Name != "" {
		updates["name"] = input.Name
	}
	if input.Address != "" {
		updates["address"] = input.Address
	}
	if input.Cell != "" {
		updates["cell"] = input.Cell
	}
	if input.Mobile != "" {
		updates["mobile"] = input.Mobile
	}
	if input.InstallationAmount != 0 {
		updates["installation_amount"] = input.InstallationAmount
	}
	if input.OtherAmount != 0 {
		updates["other_amount"] = input.OtherAmount
	}
	if input.InstallationDate != "" {
		updates["installation_date"] = input.InstallationDate
	}
	if input.RechargeDate != "" {
		updates["recharge_date"] = input.RechargeDate
	}
	if input.ConnectionProvider != "" {
		updates["connection_provider"] = input.ConnectionProvider
	}
	if input.ConnectionType != "" {
		updates["connection_type"] = input.ConnectionType
	}
	if input.BoxNumber != "" {
		updates["box_number"] = input.BoxNumber
	}
	// A full edit (one that carries connectionType) owns both package columns:
	// the side that does not apply to the connection type is cleared so a
	// subscriber who switched from "both" to internet (or cable) cannot keep a
	// stale package that the subscriber detail and collection pages would then
	// show differently. Partial updates omit connectionType and still only touch
	// the fields they send.
	newCable, newInternet := packageAssignmentAfterUpdate(old, input)
	if input.ConnectionType != "" || input.PackageCable != "" {
		updates["package_cable"] = newCable
	}
	if input.Discount != "" {
		updates["discount"] = input.Discount
	}
	if input.Amount != nil {
		updates["amount"] = *input.Amount
	}
	if input.ConnectionType != "" || input.PackageInternet != "" {
		updates["package_internet"] = newInternet
	}
	// Only touch the create-balance flag when the caller actually sent it;
	// a partial update (e.g. resetting the balance) must not flip it off.
	if input.CreateBalance != nil {
		updates["create_balance"] = *input.CreateBalance
	}
	if input.BalanceDays != 0 {
		updates["balance_days"] = input.BalanceDays
	}
	if input.SameDiscount != "" {
		updates["same_discount"] = input.SameDiscount
	}
	if input.SameAmount != nil {
		updates["same_amount"] = *input.SameAmount
	}
	if input.Status != "" {
		updates["status"] = input.Status
	}
	if input.SublocalityID != "" {
		updates["sublocality_id"] = input.SublocalityID
	}
	if input.SplitterPort != 0 {
		updates["splitter_port"] = input.SplitterPort
	}
	// Deactivation fields - always set when provided
	if input.LeavingDate != "" {
		updates["leaving_date"] = input.LeavingDate
	}
	if input.DeactivationReason != "" {
		updates["deactivation_reason"] = input.DeactivationReason
	}
	if input.Comments != "" {
		updates["comments"] = input.Comments
	}
	if input.BadDebt != nil {
		updates["bad_debt"] = *input.BadDebt
	}
	if input.PaymentStatus != nil {
		updates["payment_status"] = *input.PaymentStatus
	}
	if input.TransactionId != "" {
		updates["transaction_id"] = input.TransactionId
	}
	if input.RemainingAmount != nil {
		updates["remaining_amount"] = *input.RemainingAmount
	}

	// The package fee is the subscriber's monthly bill, so when the package
	// changes the balance is set to the new fee: moving 1000 -> 1500 leaves
	// 1500 remaining, not the old 1000. Only an actual change triggers this, so
	// saving a subscriber's phone number does not reset what they owe.
	newPackageFee, packageChanged := packageUpdateBalance(old, input)

	if packageChanged {
		updates["remaining_amount"] = newPackageFee
		// Keep the status in step with the balance just written, otherwise the
		// pending and advance pages disagree with what is actually owed.
		updates["payment_status"] = paymentStatusForBalance(newPackageFee)

		balanceChange = &connChange{
			FieldName:  "Balance",
			ActionType: "Balance Set to Package Fee",
			Old:        fmtNum(old.RemainingAmount),
			New:        fmtNum(newPackageFee) + " (new package fee)",
		}
	}

	// On top of that the operator can still create a balance by hand for a
	// mid-month change, using the same formula as a new subscriber so both paths
	// agree: fee / 30 * days. It accumulates onto whatever the balance is about
	// to be, which is the new package fee when the package also changed.
	if input.CreateBalance != nil && *input.CreateBalance && input.BalanceDays > 0 {
		manualBalance := roundToTwo(newPackageFee / 30 * float64(input.BalanceDays))

		base := old.RemainingAmount
		if staged, ok := updates["remaining_amount"].(float64); ok {
			// Includes both the package fee above and an explicit balance from
			// the caller, whichever was staged last.
			base = staged
		}
		newBalance := roundToTwo(base + manualBalance)

		updates["remaining_amount"] = newBalance
		updates["payment_status"] = paymentStatusForBalance(newBalance)

		balanceChange = &connChange{
			FieldName:  "Balance",
			ActionType: "Balance Created",
			Old:        fmtNum(old.RemainingAmount),
			New:        fmtNum(newBalance) + " (+" + fmtNum(manualBalance) + " for " + fmtInt(input.BalanceDays) + " days at " + fmtNum(newPackageFee) + " per month)",
		}
	}

	// Handle splitter changes
	newSplitterID := input.SplitterID
	if newSplitterID == "" {
		newSplitterID = old.SplitterID
	}
	if old.SplitterID != newSplitterID {
		if old.SplitterID != "" {
			if err := incrementSplitterPorts(tx, old.SplitterID); err != nil {
				tx.Rollback()
				utils.ErrorResponse(c, 500, "Failed to restore old splitter ports", err.Error())
				return
			}
		}
		if newSplitterID != "" {
			if _, err := uuid.Parse(newSplitterID); err != nil {
				tx.Rollback()
				utils.ErrorResponse(c, 400, "Invalid splitter ID", err.Error())
				return
			}
			if err := decrementSplitterPorts(tx, newSplitterID); err != nil {
				tx.Rollback()
				utils.ErrorResponse(c, 400, "Splitter port error", err.Error())
				return
			}
		}
		updates["splitter_id"] = newSplitterID
	}

	if err := tx.Model(&models.Connection{}).Where("id = ?", id).Updates(updates).Error; err != nil {
		tx.Rollback()
		utils.ErrorResponse(c, 500, "Failed to update connection", err.Error())
		return
	}

	var updated models.Connection
	if err := tx.First(&updated, "id = ?", id).Error; err != nil {
		tx.Rollback()
		utils.ErrorResponse(c, 500, "Failed to reload connection", err.Error())
		return
	}

	if err := tx.Commit().Error; err != nil {
		utils.ErrorResponse(c, 500, "Failed to commit", err.Error())
		return
	}

	reason := input.Reason
	if reason == "" {
		reason = input.DeactivationReason
	}
	changes := connectionFieldChanges(old, input)
	if balanceChange != nil {
		changes = append(changes, *balanceChange)
	}
	createConnectionLogs(c, updated, changes, reason, input.Comments)

	utils.SuccessResponse(c, "Connection updated", updated)
}

func deleteConnection(c *gin.Context) {
	id := c.Param("id")

	tx := config.DB.Begin()
	if tx.Error != nil {
		utils.ErrorResponse(c, 500, "Failed to start transaction", tx.Error.Error())
		return
	}

	var conn models.Connection
	if err := tx.First(&conn, "id = ?", id).Error; err != nil {
		tx.Rollback()
		utils.ErrorResponse(c, 404, "Connection not found", nil)
		return
	}

	if conn.SplitterID != "" {
		if err := incrementSplitterPorts(tx, conn.SplitterID); err != nil {
			tx.Rollback()
			utils.ErrorResponse(c, 500, "Failed to restore splitter ports", err.Error())
			return
		}
	}

	if err := tx.Delete(&conn).Error; err != nil {
		tx.Rollback()
		utils.ErrorResponse(c, 500, "Failed to delete connection", err.Error())
		return
	}

	if err := tx.Commit().Error; err != nil {
		utils.ErrorResponse(c, 500, "Failed to commit", err.Error())
		return
	}

	createConnectionLogs(c, conn, []connChange{{
		FieldName:  "connection",
		ActionType: "Connection Deleted",
		Old:        fmt.Sprintf("%s (%s)", conn.Name, conn.InternetID),
		New:        "",
	}}, "", "")

	utils.SuccessResponse(c, "Connection deleted", nil)
}

// connChange represents one field-level change on a connection.
type connChange struct {
	FieldName  string
	ActionType string
	Old        string
	New        string
}

func fmtNum(v float64) string {
	return strconv.FormatFloat(v, 'f', 2, 64)
}

func fmtInt(v int) string {
	return strconv.Itoa(v)
}

func fmtBool(v bool) string {
	if v {
		return "true"
	}
	return "false"
}

// connectionFieldChanges diffs the previous connection against the incoming
// input and returns one connChange per modified field.
func connectionFieldChanges(old models.Connection, input connectionInput) []connChange {
	var changes []connChange

	add := func(field, action, oldV, newV string) {
		if newV == "" || newV == oldV {
			return
		}
		changes = append(changes, connChange{FieldName: field, ActionType: action, Old: oldV, New: newV})
	}

	add("internetId", "Subscriber ID Changed", old.InternetID, input.InternetID)
	add("name", "Subscriber Name Changed", old.Name, input.Name)
	add("address", "Address Changed", old.Address, input.Address)
	add("cell", "Contact Number Changed", old.Cell, input.Cell)
	add("mobile", "Contact Number Changed", old.Mobile, input.Mobile)
	add("connectionProvider", "Provider Changed", old.ConnectionProvider, input.ConnectionProvider)
	add("connectionType", "Connection Type Changed", old.ConnectionType, input.ConnectionType)
	add("boxNumber", "Box Number Changed", old.BoxNumber, input.BoxNumber)
	add("packageCable", "Cable Package Changed", old.PackageCable, input.PackageCable)
	add("packageInternet", "Internet Package Changed", old.PackageInternet, input.PackageInternet)
	add("discount", "Discount Updated", old.Discount, input.Discount)
	add("sameDiscount", "Internet Discount Updated", old.SameDiscount, input.SameDiscount)
	add("installationDate", "Installation Date Changed", old.InstallationDate, input.InstallationDate)
	add("rechargeDate", "Recharge Date Updated", old.RechargeDate, input.RechargeDate)
	add("leavingDate", "Leaving Date Updated", old.LeavingDate, input.LeavingDate)
	add("deactivationReason", "Deactivation Reason Updated", old.DeactivationReason, input.DeactivationReason)
	add("comments", "Remarks Updated", old.Comments, input.Comments)

	if input.InstallationAmount != 0 {
		add("installationAmount", "Installation Charges Updated", fmtNum(old.InstallationAmount), fmtNum(input.InstallationAmount))
	}
	if input.OtherAmount != 0 {
		add("otherAmount", "Other Charges Updated", fmtNum(old.OtherAmount), fmtNum(input.OtherAmount))
	}
	if input.Amount != nil {
		add("amount", "Cable Price Changed", fmtNum(old.Amount), fmtNum(*input.Amount))
	}
	if input.SameAmount != nil {
		add("sameAmount", "Internet Price Changed", fmtNum(old.SameAmount), fmtNum(*input.SameAmount))
	}
	if input.BalanceDays != 0 {
		add("balanceDays", "Balance Days Updated", fmtInt(old.BalanceDays), fmtInt(input.BalanceDays))
	}
	if input.CreateBalance != nil && *input.CreateBalance != old.CreateBalance {
		add("createBalance", "Balance Setting Updated", fmtBool(old.CreateBalance), fmtBool(*input.CreateBalance))
	}
	if input.SplitterPort != 0 && input.SplitterPort != old.SplitterPort {
		add("splitterPort", "Splitter Port Changed", fmtInt(old.SplitterPort), fmtInt(input.SplitterPort))
	}
	if input.SublocalityID != "" && input.SublocalityID != old.SublocalityID {
		add("sublocalityId", "Area Changed", old.SublocalityID, input.SublocalityID)
	}
	if input.BadDebt != nil && *input.BadDebt != old.BadDebt {
		add("badDebt", "Bad Debt Flag Updated", fmtBool(old.BadDebt), fmtBool(*input.BadDebt))
	}

	newSplitter := input.SplitterID
	if newSplitter == "" {
		newSplitter = old.SplitterID
	}
	if newSplitter != old.SplitterID {
		add("splitterId", "Splitter Changed", old.SplitterID, newSplitter)
	}

	if input.Status != "" && input.Status != old.Status {
		action := "Connection Status Changed"
		switch input.Status {
		case "active":
			if old.Status == "suspended" {
				action = "Connection Resumed"
			} else {
				action = "Connection Activated"
			}
		case "suspended":
			action = "Connection Suspended"
		case "deactivated", "inactive":
			action = "Connection Disconnected"
		}
		add("status", action, old.Status, input.Status)
	}

	return changes
}

// connectionLogContext extracts the acting user, role, branch, IP and device
// from the Gin context for connection log entries.
func connectionLogContext(c *gin.Context) (userID *uuid.UUID, role, ip, device, branch string) {
	ip = c.ClientIP()
	device = c.GetHeader("User-Agent")

	if v, ok := c.Get("userID"); ok {
		if uid, ok2 := v.(uuid.UUID); ok2 {
			userID = &uid
			var user models.User
			if err := config.DB.First(&user, "id = ?", uid).Error; err == nil {
				role = user.Role
			}
		}
	}
	if v, ok := c.Get("userRoleInCompany"); ok {
		if s, ok2 := v.(string); ok2 && s != "" {
			role = s
		}
	}
	if v, ok := c.Get("companyID"); ok {
		if cid, ok2 := v.(uuid.UUID); ok2 {
			var company models.Company
			if err := config.DB.First(&company, "id = ?", cid).Error; err == nil {
				branch = company.Name
			}
		}
	}
	return
}

// createConnectionLogs writes one ConnectionLog row per change using the shared
// DB connection AFTER the main operation has committed. This guarantees a log
// write failure (e.g. missing table) can never abort the subscriber update.
func createConnectionLogs(c *gin.Context, conn models.Connection, changes []connChange, reason, remarks string) {
	if len(changes) == 0 {
		return
	}
	userID, role, ip, device, branch := connectionLogContext(c)
	now := time.Now()
	for _, ch := range changes {
		logEntry := models.ConnectionLog{
			TenantModel:    models.TenantModel{CompanyID: conn.CompanyID},
			ConnectionID:   conn.ID,
			SubscriberName: conn.Name,
			InternetID:     conn.InternetID,
			ConnectionType: conn.ConnectionType,
			ActionType:     ch.ActionType,
			FieldName:      ch.FieldName,
			OldValue:       ch.Old,
			NewValue:       ch.New,
			Reason:         reason,
			Remarks:        remarks,
			UpdatedBy:      userID,
			UserRole:       role,
			Branch:         branch,
			IPAddress:      ip,
			DeviceName:     device,
			LogDate:        now.Format("2006-01-02"),
			LogTime:        now.Format("15:04:05"),
		}
		if err := config.DB.Create(&logEntry).Error; err != nil {
			fmt.Printf("Failed to create connection log: %v\n", err)
		}
	}
}

func getConnectionLogs(c *gin.Context) {
	companyID := c.MustGet("companyID").(uuid.UUID)

	db := config.DB.Scopes(models.TenantScope(companyID))

	if s := c.Query("search"); s != "" {
		db = db.Where("subscriber_name ILIKE ? OR internet_id ILIKE ?", "%"+s+"%", "%"+s+"%")
	}
	if a := c.Query("actionType"); a != "" {
		db = db.Where("action_type = ?", a)
	}
	if u := c.Query("updatedBy"); u != "" {
		db = db.Where("updated_by = ?", u)
	}
	if t := c.Query("connectionType"); t != "" && t != "both" {
		db = db.Where("connection_type = ?", t)
	}
	if from := c.Query("from"); from != "" {
		db = db.Where("log_date >= ?", from)
	}
	if to := c.Query("to"); to != "" {
		db = db.Where("log_date <= ?", to)
	}

	var logs []models.ConnectionLog
	if err := db.Order("created_at DESC").Find(&logs).Error; err != nil {
		utils.ErrorResponse(c, 500, "Failed to fetch connection logs", err.Error())
		return
	}

	userMap := map[string]string{}
	var users []models.User
	if err := config.DB.Find(&users).Error; err == nil {
		for _, u := range users {
			userMap[u.ID.String()] = u.Name
		}
	}

	branch := ""
	if v, ok := c.Get("companyID"); ok {
		if cid, ok2 := v.(uuid.UUID); ok2 {
			var company models.Company
			if err := config.DB.First(&company, "id = ?", cid).Error; err == nil {
				branch = company.Name
			}
		}
	}

	for i := range logs {
		if logs[i].UpdatedBy != nil {
			if n, ok := userMap[logs[i].UpdatedBy.String()]; ok {
				logs[i].UpdatedByName = n
			}
		}
		if logs[i].Branch == "" {
			logs[i].Branch = branch
		}
	}

	utils.SuccessResponse(c, "Connection logs retrieved", logs)
}

// roundToTwo rounds a money value to two decimal places.
func roundToTwo(x float64) float64 {
	return math.Round(x*100) / 100
}

// monthlyPackageFee mirrors the billing rule used by Bill Creator so proration
// is always based on the exact fee the subscriber would otherwise be charged.
func monthlyPackageFee(connectionType string, amount, sameAmount float64) float64 {
	switch connectionType {
	case "internet":
		return sameAmount
	case "both":
		return amount + sameAmount
	default:
		return amount
	}
}

// packageFeeAfterUpdate resolves the monthly fee that will be in force once the
// update is applied, mirroring the handler's zero-value guards so proration is
// never based on a value the database would not actually store.
func packageFeeAfterUpdate(old models.Connection, input connectionInput) float64 {
	amount, sameAmount := old.Amount, old.SameAmount
	if input.Amount != nil {
		amount = *input.Amount
	}
	if input.SameAmount != nil {
		sameAmount = *input.SameAmount
	}

	connectionType := old.ConnectionType
	if input.ConnectionType != "" {
		connectionType = input.ConnectionType
	}

	return monthlyPackageFee(connectionType, amount, sameAmount)
}

// valueOrZero reads an optional money field, treating an omitted value as zero.
func valueOrZero(v *float64) float64 {
	if v == nil {
		return 0
	}
	return *v
}

// packageAssignmentAfterUpdate resolves the package names a connection should
// carry after an update.
//
// A full edit (one that includes connectionType) owns both package columns, and
// the side that does not apply to the connection type is cleared. That stops a
// subscriber who switched from "both" to internet-only (or cable-only) keeping
// a stale package that the subscriber detail and collection pages would then
// display differently. A partial update that omits connectionType leaves the
// package columns it did not send untouched.
func packageAssignmentAfterUpdate(old models.Connection, input connectionInput) (cable, internet string) {
	cable, internet = old.PackageCable, old.PackageInternet

	if input.ConnectionType == "" {
		if input.PackageCable != "" {
			cable = input.PackageCable
		}
		if input.PackageInternet != "" {
			internet = input.PackageInternet
		}
		return
	}

	return packagesForType(input.ConnectionType, input.PackageCable, input.PackageInternet)
}

// packagesForType returns the package names that are actually in use for a
// connection type. A value stored on the side the type does not use is ignored.
func packagesForType(connectionType, cable, internet string) (string, string) {
	switch strings.ToLower(strings.TrimSpace(connectionType)) {
	case "internet":
		return "", internet
	case "tv_cable":
		return cable, ""
	default:
		return cable, internet
	}
}

// paymentStatusForBalance mirrors the status rules used when a payment is
// applied: a positive balance is pending, a negative one is an advance.
// packageUpdateBalance resolves the monthly fee that will be in force after an
// update and reports whether the package actually changed. The fee is the
// subscriber's bill, so a changed package leaves the new fee as the balance.
//
// The change check compares the package names and the fee, and treats an omitted
// field as "unchanged" the same way the handler does, so re-saving a subscriber
// without touching the package never resets what they owe.
func packageUpdateBalance(old models.Connection, input connectionInput) (float64, bool) {
	fee := roundToTwo(packageFeeAfterUpdate(old, input))
	oldFee := roundToTwo(monthlyPackageFee(old.ConnectionType, old.Amount, old.SameAmount))

	newType := old.ConnectionType
	if input.ConnectionType != "" {
		newType = input.ConnectionType
	}
	storedCable, storedInternet := packageAssignmentAfterUpdate(old, input)
	oldCable, oldInternet := packagesForType(old.ConnectionType, old.PackageCable, old.PackageInternet)
	newCable, newInternet := packagesForType(newType, storedCable, storedInternet)

	// Compare the package sides that are actually in use. Clearing a stale
	// value on a side the connection type does not use must not look like a
	// package change, or an unrelated edit would reset the balance.
	changed := newCable != oldCable ||
		newInternet != oldInternet ||
		fee != oldFee

	return fee, changed
}

func paymentStatusForBalance(remaining float64) string {
	switch {
	case remaining > 0:
		return "pending"
	case remaining < 0:
		return "advance"
	default:
		return ""
	}
}
