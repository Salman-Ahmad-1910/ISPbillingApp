package config

import (
	"awesomeProject/models"
	"fmt"
	"log"
	"os"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

var DB *gorm.DB

func ConnectDatabase() {
	dsn := fmt.Sprintf(
		"host=%s user=%s password=%s dbname=%s port=%s sslmode=disable TimeZone=UTC",
		os.Getenv("DB_HOST"),
		os.Getenv("DB_USER"),
		os.Getenv("DB_PASSWORD"),
		os.Getenv("DB_NAME"),
		os.Getenv("DB_PORT"),
	)

	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{
		Logger: logger.Default.LogMode(logger.Info),
	})

	if err != nil {
		log.Fatal("Failed to connect to database:", err)
	}

	DB = db
	log.Println("Database connection established")
}

func RunMigrations() {
	log.Println("Running AutoMigration...")

	// Create custom enum types manually before auto-migration
	createEnumTypes()

	// Convert unit_type columns from enum to varchar
	log.Println("Converting unit_type columns from enum to varchar...")
	DB.Exec(`ALTER TABLE products ALTER COLUMN unit_type TYPE varchar(50)`)
	DB.Exec(`ALTER TABLE vendor_invoice_items ALTER COLUMN unit_type TYPE varchar(50)`)
	log.Println("unit_type columns converted")

	// Drop FK constraints that were removed from models
	log.Println("Dropping removed FK constraints...")
	dropRemovedSubscriberForeignKeys()
	DB.Exec(`ALTER TABLE invoices ALTER COLUMN subscriber_id DROP NOT NULL`)
	DB.Exec(`ALTER TABLE payments ALTER COLUMN subscriber_id DROP NOT NULL`)
	DB.Exec(`ALTER TABLE payments ALTER COLUMN invoice_id DROP NOT NULL`)
	DB.Exec(`ALTER TABLE inquiries ALTER COLUMN phone DROP NOT NULL`)
	log.Println("FK constraints dropped")

	err := DB.AutoMigrate(
		&models.Company{},
		&models.User{},
		&models.UserCompany{},
		&models.Role{},
		&models.Permission{},
		&models.RolePermission{},
		&models.UserPermission{},

		&models.Area{},
		&models.AreaOfficer{},
		&models.OLT{},
		&models.Splitter{},
		&models.POP{},

		&models.Package{},
		&models.Subscriber{},
		&models.Inquiry{},
		&models.CorporateCustomer{},

		&models.Invoice{},
		&models.Payment{},
		&models.CustomBill{},
		&models.Promise{},
		&models.LedgerEntry{},
		&models.Expense{},

		&models.DealerFranchise{},
		&models.Dealer{},
		&models.DealerCollection{},

		&models.Complaint{},
		&models.ComplaintSubject{},
		&models.ComplaintType{},
		&models.Staff{},
		&models.StaffQualification{},
		&models.StaffExperience{},
		&models.StaffWorkTime{},
		&models.StaffDepartment{},
		&models.RecoveryOfficer{}, // Add Recovery Officer model
		&models.Attendance{},
		&models.AdvanceLoan{},
		&models.SalaryPayment{},
		&models.InventoryItem{},
		&models.RecoveryTransaction{},
		&models.SystemLog{},

		&models.Customer{},
		&models.Guarantor{},
		&models.Product{},
		&models.Vendor{},
		&models.VendorInvoice{},
		&models.VendorInvoiceItem{},
		&models.InstallmentPlan{},
		&models.PricingPlan{},
		&models.Sale{},
		&models.SaleItem{},
		&models.AlertTemplate{},
		&models.SystemConfig{},
		&models.SupportTicket{},
		&models.Brand{},
		&models.UnitType{},
		&models.ProductType{},
		&models.InventoryStatus{},
		&models.Purchase{},
		&models.PurchaseItem{},
		&models.PurchaseQuantityHistory{},
		&models.DistributionBox{},
		&models.Connection{},
		&models.ConnectionStatusChange{},
		&models.ConnectionLog{},
		&models.TransactionType{},
		&models.BillRecord{},
		&models.AccountHead{},
		&models.AccountSubHead{},
		&models.AccountEntry{},
		&models.SubscriberInstallment{},
		&models.POSPromise{},
		&models.POSPromiseCollection{},
		&models.FiberJointing{},
		&models.FiberJointingPayment{},
		&models.Message{},
		&models.MessageTemplate{},
		&models.SerialNumberPool{},
		&models.SharedFile{},
	)

	if err != nil {
		log.Printf("Migration warning (non-fatal): %v", err)
		// Continue despite migration errors so cleanup statements below can run
	} else {
		log.Println("Migration completed successfully")
	}

	// Migrate legacy single recovery_officer_id assignments (nullable column on
	// areas) into the new many-to-many area_officers table, then drop the old
	// column now that the model uses the join table.
	if DB.Migrator().HasColumn(&models.Area{}, "recovery_officer_id") {
		log.Println("Migrating legacy area recovery_officer_id into area_officers...")
		// Remove any duplicate area_officer rows from earlier partial runs so the
		// unique index can be created.
		DB.Exec(`
			DELETE FROM area_officers a
			USING area_officers b
			WHERE a.id < b.id
				AND a.area_id = b.area_id
				AND a.recovery_officer_id = b.recovery_officer_id
		`)
		DB.Exec("DROP INDEX IF EXISTS idx_area_officer")
		if err := DB.Exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_area_officer ON area_officers (area_id, recovery_officer_id)").Error; err != nil {
			log.Printf("Warning: failed to create area_officers unique index: %v", err)
			return
		}
		if err := DB.Exec(`
			INSERT INTO area_officers (id, company_id, area_id, recovery_officer_id, created_at, updated_at)
			SELECT gen_random_uuid(), a.company_id, a.id, a.recovery_officer_id, NOW(), NOW()
			FROM areas a
			WHERE a.recovery_officer_id IS NOT NULL AND a.deleted_at IS NULL
			ON CONFLICT (area_id, recovery_officer_id) DO NOTHING
		`).Error; err != nil {
			log.Printf("Warning: failed to migrate legacy area assignments: %v", err)
			return
		}
		DB.Exec("ALTER TABLE areas DROP COLUMN IF EXISTS recovery_officer_id")
		log.Println("✓ Area officer assignments migrated to join table")
	}

	// Drop FK constraints that GORM AutoMigrate may recreate but that have
	// orphaned data preventing creation.
	dropRemovedSubscriberForeignKeys()
	log.Println("FK constraints cleaned up after migration")

	// Product ID (product_code) must be unique per company, not globally, so each
	// company can have its own Pr-001, Pr-002, ... sequence. The backend assigns
	// the id in Product.BeforeCreate by querying MAX(product_code) within the
	// company; this composite unique index is the per-company safety net.
	DB.Exec(`DROP INDEX IF EXISTS idx_products_product_code`)
	DB.Exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_products_company_product_code ON products (company_id, product_code)`)
	log.Println("Product ID uniqueness scoped per company")

	// Backfill installment_plans: set percentage_increase to 0 for existing rows
	DB.Exec("UPDATE installment_plans SET percentage_increase = 0 WHERE percentage_increase IS NULL")
	// Backfill purchase item "entered" quantity for existing rows: the stored
	// quantity is the remaining stock (reduced by sales), but the purchases page
	// should display the quantity that was originally entered.
	// 1) Rows that still hold stock: the best lower bound we know is what's left.
	// 2) Rows that are fully consumed: recover the entered quantity from the
	//    purchase total when the purchase is a single line and the implied
	//    subtotal (total + discount - sales_tax - wth_tax) divides exactly by
	//    the unit price.
	DB.Exec("UPDATE purchase_items SET quantity_entered = quantity WHERE quantity_entered = 0 AND quantity > 0")
	DB.Exec(`
		UPDATE purchase_items pi
		SET quantity_entered = ROUND((p.total_amount + p.discount - p.sales_tax - p.wth_tax) / pi.purchase_price)
		FROM purchases p
		WHERE pi.purchase_id = p.id
			AND p.deleted_at IS NULL AND pi.deleted_at IS NULL
			AND pi.quantity_entered = 0
			AND (p.total_amount + p.discount - p.sales_tax - p.wth_tax) > 0
			AND pi.purchase_price > 0
			AND (ROUND((p.total_amount + p.discount - p.sales_tax - p.wth_tax) / pi.purchase_price)
				= ((p.total_amount + p.discount - p.sales_tax - p.wth_tax) / pi.purchase_price))
			AND (SELECT COUNT(*) FROM purchase_items x WHERE x.purchase_id = p.id AND x.deleted_at IS NULL) = 1
	`)
	log.Println("Purchase item entered quantity backfilled")

	// Backfill product models for products bought before the Model field existed:
	// aggregate the models of their vendor-invoice items in creation order so the
	// existing products table and expanded SN rows show models.
	DB.Exec(`
		UPDATE products p
		SET model = agg.models
		FROM (
			SELECT vi.product_id, string_agg(vi.model, E'\n' ORDER BY vi.created_at) AS models
			FROM vendor_invoice_items vi
			WHERE vi.deleted_at IS NULL AND vi.model IS NOT NULL AND trim(vi.model) <> ''
			GROUP BY vi.product_id
		) agg
		WHERE p.id = agg.product_id
			AND p.deleted_at IS NULL
			AND (p.model IS NULL OR trim(p.model) = '')
	`)
	log.Println("Product models backfilled")

	// Drop old columns from installment_plans that no longer exist in the model
	DB.Exec("ALTER TABLE installment_plans DROP COLUMN IF EXISTS product_id")
	DB.Exec("ALTER TABLE installment_plans DROP COLUMN IF EXISTS product_name")
	DB.Exec("ALTER TABLE installment_plans DROP COLUMN IF EXISTS down_payment")
	DB.Exec("ALTER TABLE installment_plans DROP COLUMN IF EXISTS installment_amount")
	DB.Exec("ALTER TABLE installment_plans DROP COLUMN IF EXISTS total_amount")

	// Add status and discount columns to sales if they don't exist
	DB.Exec("ALTER TABLE sales ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'completed'")
	DB.Exec("ALTER TABLE sales ADD COLUMN IF NOT EXISTS discount DECIMAL(10,2) DEFAULT 0")

	// Drop old down_payment column from subscriber_installments
	DB.Exec("ALTER TABLE subscriber_installments DROP COLUMN IF EXISTS down_payment")

	// Fix unique indexes: drop global unique indexes on purchase_number and
	// invoice_number, then create composite (company_id, ...) unique indexes.
	// This allows different companies to have the same purchase/invoice numbers.
	DB.Exec("DROP INDEX IF EXISTS uniq_purchase_company")
	DB.Exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_purchase_company_number ON purchases (company_id, purchase_number) WHERE deleted_at IS NULL")

	DB.Exec("DROP INDEX IF EXISTS uniq_vendor_invoice_company")
	DB.Exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_vendor_invoice_company_number ON vendor_invoices (company_id, invoice_number) WHERE deleted_at IS NULL")

	// Distribution box name must be unique per company, not globally, so two
	// different companies can independently use the same box name. Drop the
	// old whole-column unique index and recreate it as (company_id, name).
	DB.Exec("DROP INDEX IF EXISTS idx_box_name_company")
	DB.Exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_box_name_company ON distribution_boxes (company_id, name)")
	log.Println("Distribution box name uniqueness scoped per company")

	// Internet ID must be unique per company, not globally: each company may
	// independently use the same internet_id. Drop any leftover whole-column
	// index (created by older versions) and recreate it as (company_id,
	// internet_id), so two different companies can add subscribers with the
	// same internet ID.
	DB.Exec("DROP INDEX IF EXISTS idx_connection_internet_id_company")
	DB.Exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_connection_internet_id_company
		ON connections (company_id, internet_id)
		WHERE internet_id IS NOT NULL AND internet_id <> ''`)
	log.Println("Connection internet ID uniqueness scoped per company")

	// Same for transaction_id: kept unique per company (empty values and
	// deactivated rows are excluded to avoid blocking re-use).
	DB.Exec("DROP INDEX IF EXISTS idx_connection_transaction_id")
	DB.Exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_connection_transaction_id
		ON connections (transaction_id, company_id)
		WHERE transaction_id IS NOT NULL AND transaction_id <> '' AND deleted_at IS NULL`)
	// Drop the per-company transaction_id index before recreating it so that any
	// stale/older definition with the same index name (e.g. a global unique
	// index on transaction_id alone from a previous deploy) is replaced. Without
	// the DROP, "CREATE ... IF NOT EXISTS" is a no-op and the old wrong index
	// keeps blocking same transaction_id across different companies.
	DB.Exec("DROP INDEX IF EXISTS idx_connection_transaction_id_company")
	DB.Exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_connection_transaction_id_company
		ON connections (company_id, transaction_id)
		WHERE transaction_id IS NOT NULL AND transaction_id <> ''`)
	log.Println("Connection transaction ID uniqueness scoped per company")

	// Backfill connection status change log:
	// 1) Initial creation record for every connection
	// 2) Last status change for connections currently non-active (approximated via updated_at)
	log.Println("Backfilling connection status changes...")
	DB.Exec(`
		INSERT INTO connection_status_changes (id, connection_id, company_id, old_status, new_status, changed_at)
		SELECT gen_random_uuid(), c.id, c.company_id, NULL, 'active', c.created_at
		FROM connections c
		LEFT JOIN connection_status_changes csc ON csc.connection_id = c.id AND csc.old_status IS NULL
		WHERE csc.id IS NULL AND c.deleted_at IS NULL
	`)
	DB.Exec(`
		INSERT INTO connection_status_changes (id, connection_id, company_id, old_status, new_status, changed_at)
		SELECT gen_random_uuid(), c.id, c.company_id, 'active', c.status, c.updated_at
		FROM connections c
		WHERE c.deleted_at IS NULL AND c.status != 'active'
		AND NOT EXISTS (
			SELECT 1 FROM connection_status_changes csc
			WHERE csc.connection_id = c.id AND csc.old_status = 'active' AND csc.new_status != 'active'
		)
	`)
	log.Println("✓ Connection status changes backfilled")

	// Create trigger to log status changes on connections table
	log.Println("Creating connection status change trigger...")
	DB.Exec(`
		CREATE OR REPLACE FUNCTION log_connection_status_change()
		RETURNS TRIGGER AS $$
		BEGIN
			IF TG_OP = 'INSERT' THEN
				INSERT INTO connection_status_changes (id, connection_id, company_id, old_status, new_status, changed_at)
				VALUES (gen_random_uuid(), NEW.id, NEW.company_id, NULL, NEW.status, NOW());
			ELSIF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
				INSERT INTO connection_status_changes (id, connection_id, company_id, old_status, new_status, changed_at)
				VALUES (gen_random_uuid(), NEW.id, NEW.company_id, OLD.status, NEW.status, NOW());
			END IF;
			RETURN NEW;
		END;
		$$ LANGUAGE plpgsql;
	`)
	DB.Exec(`
		DROP TRIGGER IF EXISTS trg_connection_status_change ON connections;
	`)
	DB.Exec(`
		CREATE TRIGGER trg_connection_status_change
		AFTER INSERT OR UPDATE OF status ON connections
		FOR EACH ROW
		EXECUTE FUNCTION log_connection_status_change();
	`)
	log.Println("✓ Connection status change trigger created")

	// Package number unique per company
	DB.Exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_package_company_number ON packages (company_id, package_number) WHERE deleted_at IS NULL")

	// Seed initial data
	seedInitialData()
}

// dropRemovedSubscriberForeignKeys removes the legacy foreign keys that used to
// link invoices and payments to subscribers/invoices. Those relations no longer
// exist in the models: subscriber data moved from the `subscribers` table to
// `connections`, and Invoice has no Subscriber relation (see models/billing.go).
//
// The constraints are matched from pg_constraint rather than dropped by a
// hardcoded name. The old statements named `fk_invoices_subscriber` (singular)
// while the constraint actually created on the server is
// `fk_invoices_subscribers` (plural), so `DROP CONSTRAINT IF EXISTS` silently
// did nothing and the constraint survived every boot. That left Postgres
// validating existing rows against an empty `subscribers` table, which is what
// produced the foreign key error during migration.
//
// Selecting by OID from the catalogs (instead of casting 'invoices'::regclass)
// keeps this a no-op on a brand-new database where the tables do not exist yet
// and AutoMigrate has not created them.
func dropRemovedSubscriberForeignKeys() {
	const q = `
DO $$
DECLARE
	r record;
BEGIN
	FOR r IN
		SELECT con.conrelid::regclass::text AS table_name, con.conname
		FROM pg_constraint con
		JOIN pg_class rel ON rel.oid = con.conrelid
		JOIN pg_namespace ns ON ns.oid = rel.relnamespace
		WHERE con.contype = 'f'
			AND ns.nspname = 'public'
			AND rel.relname IN ('invoices', 'payments')
			AND con.confrelid IN (
				SELECT c.oid
				FROM pg_class c
				JOIN pg_namespace n2 ON n2.oid = c.relnamespace
				WHERE c.relname IN ('subscribers', 'invoices')
					AND n2.nspname = 'public'
			)
	LOOP
		EXECUTE format('ALTER TABLE %s DROP CONSTRAINT %I', r.table_name, r.conname);
		RAISE NOTICE 'dropped leftover FK % -> %', r.table_name, r.conname;
	END LOOP;
END $$;`

	if err := DB.Exec(q).Error; err != nil {
		log.Printf("Warning: failed to drop leftover subscriber foreign keys: %v", err)
	}
}

func seedInitialData() {
	log.Println("Seeding initial data...")

	// Seed unit types
	var unitTypeCount int64
	DB.Model(&models.UnitType{}).Count(&unitTypeCount)
	if unitTypeCount == 0 {
		unitTypes := []models.UnitType{
			{Name: "piece", Label: "Per Piece"},
			{Name: "meter", Label: "Per Meter"},
			{Name: "kilogram", Label: "Per Kilogram"},
			{Name: "liter", Label: "Per Liter"},
		}
		for _, ut := range unitTypes {
			DB.Where("name = ?", ut.Name).FirstOrCreate(&ut)
		}
		log.Println("✓ Unit types seeded")
	}

	// Seed default transaction types for every company
	var companies []models.Company
	DB.Find(&companies)
	seedTransactionTypes := []models.TransactionType{
		{Transaction: "Cash", PaymentChannel: "Cash"},
		{Transaction: "Easypaisa", PaymentChannel: "Easypaisa"},
		{Transaction: "JazzCash", PaymentChannel: "JazzCash"},
		{Transaction: "Bank Al-Habib", PaymentChannel: "Bank Al-Habib"},
		{Transaction: "Meezan Bank", PaymentChannel: "Meezan Bank"},
	}
	for _, comp := range companies {
		for _, tt := range seedTransactionTypes {
			var existing int64
			DB.Model(&models.TransactionType{}).
				Where("company_id = ? AND transaction = ?", comp.ID, tt.Transaction).
				Count(&existing)
			if existing == 0 {
				tt.CompanyID = comp.ID
				DB.Create(&tt)
			}
		}
	}
	log.Println("✓ Transaction types seeded")

	// Seed inventory statuses
	var statusCount int64
	DB.Model(&models.InventoryStatus{}).Count(&statusCount)
	if statusCount == 0 {
		statuses := []models.InventoryStatus{
			{Name: "in_stock", Label: "In Stock", Color: "#22c55e", Description: "Item is available in stock"},

			{Name: "assigned", Label: "Assigned", Color: "#3b82f6", Description: "Item assigned to a subscriber"},
			{Name: "damaged", Label: "Damaged", Color: "#ef4444", Description: "Item is damaged or defective"},
			{Name: "returned", Label: "Returned", Color: "#f59e0b", Description: "Item has been returned"},
		}
		for _, s := range statuses {
			DB.Where("name = ?", s.Name).FirstOrCreate(&s)
		}
		log.Println("✓ Inventory statuses seeded")
	}

	log.Println("Initial data seeding completed")
}

func createEnumTypes() {
	log.Println("Creating custom enum types...")

	// Create unit_type_enum type with better error handling
	enumSQL := `CREATE TYPE IF NOT EXISTS unit_type_enum AS ENUM ('piece', 'meter', 'kilogram', 'liter')`

	if err := DB.Exec(enumSQL).Error; err != nil {
		log.Printf("Warning: Failed to create unit_type_enum with IF NOT EXISTS: %v", err)
		// Try alternative approach
		altEnumSQL := `DO $$ BEGIN
			CREATE TYPE unit_type_enum AS ENUM ('piece', 'meter', 'kilogram', 'liter');
		EXCEPTION
			WHEN duplicate_object THEN NULL;
		END $$;`

		if err2 := DB.Exec(altEnumSQL).Error; err2 != nil {
			log.Printf("Error: Failed to create unit_type_enum with alternative approach: %v", err2)
		} else {
			log.Println("unit_type_enum created successfully (alternative approach)")
		}
	} else {
		log.Println("unit_type_enum created successfully")
	}

	// Create status_enum type
	statusEnumSQL := `CREATE TYPE IF NOT EXISTS status_enum AS ENUM ('active', 'inactive', 'pending', 'completed', 'cancelled')`

	if err := DB.Exec(statusEnumSQL).Error; err != nil {
		log.Printf("Warning: Failed to create status_enum with IF NOT EXISTS: %v", err)
		// Try alternative approach
		altStatusSQL := `DO $$ BEGIN
			CREATE TYPE status_enum AS ENUM ('active', 'inactive', 'pending', 'completed', 'cancelled');
		EXCEPTION
			WHEN duplicate_object THEN NULL;
		END $$;`

		if err2 := DB.Exec(altStatusSQL).Error; err2 != nil {
			log.Printf("Error: Failed to create status_enum with alternative approach: %v", err2)
		} else {
			log.Println("status_enum created successfully (alternative approach)")
		}
	} else {
		log.Println("status_enum created successfully")
	}

	// Create gender_enum type
	genderEnumSQL := `CREATE TYPE IF NOT EXISTS gender_enum AS ENUM ('male', 'female', 'other')`

	if err := DB.Exec(genderEnumSQL).Error; err != nil {
		log.Printf("Warning: Failed to create gender_enum with IF NOT EXISTS: %v", err)
		// Try alternative approach
		altGenderSQL := `DO $$ BEGIN
			CREATE TYPE gender_enum AS ENUM ('male', 'female', 'other');
		EXCEPTION
			WHEN duplicate_object THEN NULL;
		END $$;`

		if err2 := DB.Exec(altGenderSQL).Error; err2 != nil {
			log.Printf("Error: Failed to create gender_enum with alternative approach: %v", err2)
		} else {
			log.Println("gender_enum created successfully (alternative approach)")
		}
	} else {
		log.Println("gender_enum created successfully")
	}

	// Verify enum types were created
	log.Println("Verifying enum types...")
	var enumExists bool

	// Check unit_type_enum
	DB.Raw("SELECT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'unit_type_enum')").Scan(&enumExists)
	if enumExists {
		log.Println("✓ unit_type_enum exists")
	} else {
		log.Println("✗ unit_type_enum does not exist")
	}

	// Check status_enum
	DB.Raw("SELECT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'status_enum')").Scan(&enumExists)
	if enumExists {
		log.Println("✓ status_enum exists")
	} else {
		log.Println("✗ status_enum does not exist")
	}

	// Check gender_enum
	DB.Raw("SELECT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'gender_enum')").Scan(&enumExists)
	if enumExists {
		log.Println("✓ gender_enum exists")
	} else {
		log.Println("✗ gender_enum does not exist")
	}
}
