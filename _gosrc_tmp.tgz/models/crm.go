package models

import (
	"fmt"
	"strings"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// Customer - Specific to Installment / Product Sales Tracking
type Customer struct {
	TenantModel
	Name               string  `gorm:"type:varchar(255);not null" json:"name"`
	Cnic               string  `gorm:"type:varchar(20);not null" json:"cnic"`
	Phone              string  `gorm:"type:varchar(20);not null" json:"phone"`
	City               string  `gorm:"type:varchar(100);not null" json:"city"`
	Status             string  `gorm:"type:varchar(20);default:'active'" json:"status"` // active, inactive, blacklisted
	TotalInvoices      int     `gorm:"default:0" json:"totalInvoices"`
	OutstandingBalance float64 `gorm:"type:decimal(10,2);default:0" json:"outstandingBalance"`
}

// Guarantor - Vouched individual for a Customer Installment Plan
type Guarantor struct {
	TenantModel
	Name         string    `gorm:"type:varchar(255);not null" json:"name"`
	Cnic         string    `gorm:"type:varchar(20);not null" json:"cnic"`
	Phone        string    `gorm:"type:varchar(20);not null" json:"phone"`
	CustomerID   uuid.UUID `gorm:"type:uuid;not null;index" json:"customerId"`
	CustomerName string    `gorm:"type:varchar(255)" json:"customerName"`
}

// Product - Point of Sale items / General Items
// BeforeCreate hook to auto-generate the human-readable product code (Product ID).
// The internal unique identifier is the UUID primary key (TenantModel.ID);
// product_code is the display id shown in the UI as "Pr-001", "Pr-002", ...
func (p *Product) BeforeCreate(tx *gorm.DB) error {
	if p.ProductCode == "" {
		var maxNum int
		tx.Unscoped().Model(&Product{}).
			Where("company_id = ? AND product_code LIKE ?", p.CompanyID, "Pr-%").
			Select("COALESCE(MAX(CAST(SUBSTRING(product_code FROM '\\d+$') AS INTEGER)), 0)").
			Scan(&maxNum)
		p.ProductCode = fmt.Sprintf("Pr-%03d", maxNum+1)
	}
	return nil
}

type Product struct {
	TenantModel
	ProductCode        string  `gorm:"type:varchar(50)" json:"productId"`
	Name               string  `gorm:"type:varchar(255);not null" json:"name"`
	Category           string  `gorm:"type:varchar(100);not null" json:"category"`
	Price              float64 `gorm:"type:decimal(10,2);not null" json:"price"`
	Stock              int     `gorm:"not null;default:0" json:"stock"`
	UnitType           string  `gorm:"type:varchar(50);not null;default:'piece'" json:"unitType"`
	TaxPercent         float64 `gorm:"type:decimal(5,2);not null;default:0" json:"taxPercent"`
	Image              string  `gorm:"type:varchar(255)" json:"image"`
	SalePrice          float64 `gorm:"type:decimal(10,2);not null;default:0" json:"salePrice"`
	PurchasePrice      float64 `gorm:"type:decimal(10,2);not null;default:0" json:"purchasePrice"`
	Discount           float64 `gorm:"type:decimal(10,2);not null;default:0" json:"discount"`
	BrandID            string  `gorm:"type:varchar(100)" json:"brandId"`
	BrandName          string  `gorm:"type:varchar(255)" json:"brandName"`
	ProductTypeID      string  `gorm:"type:varchar(100)" json:"productTypeId"`
	ProductTypeName    string  `gorm:"type:varchar(255)" json:"productTypeName"`
	SerialNumber       string  `gorm:"type:text" json:"serialNumber"`
	NoSerialNumber     bool    `gorm:"not null;default:false" json:"noSerialNumber"`
	CurrentSerialIndex int     `gorm:"not null;default:0" json:"currentSerialIndex"`
	Model              string  `gorm:"type:text" json:"model"`
	CurrentModelIndex  int     `gorm:"not null;default:0" json:"currentModelIndex"`
}

func (p *Product) ParseSerialNumbers() []string {
	if p.SerialNumber == "" {
		return nil
	}
	parts := strings.FieldsFunc(p.SerialNumber, func(r rune) bool {
		return r == ',' || r == ' ' || r == '-'
	})
	var result []string
	for _, s := range parts {
		s = strings.TrimSpace(s)
		if s != "" {
			result = append(result, s)
		}
	}
	return result
}

func (p *Product) GetCurrentSerialNumber() string {
	sns := p.ParseSerialNumbers()
	if len(sns) == 0 {
		return p.SerialNumber
	}
	if p.CurrentSerialIndex >= 0 && p.CurrentSerialIndex < len(sns) {
		return sns[p.CurrentSerialIndex]
	}
	return sns[0]
}

func (p *Product) AdvanceSerialNumber() string {
	sns := p.ParseSerialNumbers()
	if len(sns) == 0 {
		return p.SerialNumber
	}
	current := p.GetCurrentSerialNumber()
	if p.CurrentSerialIndex < len(sns)-1 {
		p.CurrentSerialIndex++
	}
	return current
}

func (p *Product) ParseModels() []string {
	if p.Model == "" {
		return nil
	}
	parts := strings.FieldsFunc(p.Model, func(r rune) bool {
		return r == ',' || r == '\n' || r == '\r' || r == '\t'
	})
	var result []string
	for _, s := range parts {
		s = strings.TrimSpace(s)
		if s != "" {
			result = append(result, s)
		}
	}
	return result
}

func (p *Product) GetCurrentModel() string {
	models := p.ParseModels()
	if len(models) == 0 {
		return p.Model
	}
	if p.CurrentModelIndex >= 0 && p.CurrentModelIndex < len(models) {
		return models[p.CurrentModelIndex]
	}
	return models[0]
}

// SerialNumberPool - Pool of serial numbers to be auto-assigned to products
type SerialNumberPool struct {
	TenantModel
	SerialNumber string `gorm:"type:text;not null;index" json:"serialNumber"`
	Status       string `gorm:"type:varchar(50);not null;default:'available'" json:"status"` // available | used
	ProductID    string `gorm:"type:varchar(100)" json:"productId"`
}

// InstallmentPlan - Defined schedule for physical goods
type InstallmentPlan struct {
	TenantModel
	Name               string  `gorm:"type:varchar(255);not null" json:"name"`
	Installments       int     `gorm:"not null" json:"installments"`
	PercentageIncrease float64 `gorm:"type:decimal(5,2);not null;default:0" json:"percentageIncrease"`
}

// PricingPlans (SaaS tier definition, different from package context, mainly root level)
type PricingPlan struct {
	TenantModel
	Name     string  `gorm:"type:varchar(100);not null" json:"name"`
	Price    float64 `gorm:"type:decimal(10,2);not null" json:"price"`
	Features string  `gorm:"type:text" json:"features"` // comma separated or JSON string
}

// Sale - Point of Sale Transaction
type Sale struct {
	TenantModel
	SubscriberID   uuid.UUID  `gorm:"type:uuid;not null;index" json:"subscriberId"`
	SubscriberName string     `gorm:"type:varchar(255)" json:"subscriberName"`
	TotalAmount    float64    `gorm:"type:decimal(10,2);not null" json:"totalAmount"`
	TaxAmount      float64    `gorm:"type:decimal(10,2);not null" json:"taxAmount"`
	PaymentMethod  string     `gorm:"type:varchar(50);not null" json:"paymentMethod"`
	Date           string     `gorm:"type:varchar(50);not null" json:"date"`
	IsInstallment  bool       `gorm:"default:false" json:"isInstallment"`
	Status         string     `gorm:"type:varchar(20);default:'completed'" json:"status"`
	Discount       float64    `gorm:"type:decimal(10,2);default:0" json:"discount"`
	ReplacedFrom   string     `gorm:"type:jsonb;default:null" json:"replacedFrom"` // snapshot of the ORIGINAL items captured when this sale was replaced
	Items          []SaleItem `gorm:"foreignKey:SaleID;constraint:OnDelete:CASCADE" json:"items"`

	// SaleType tags the origin of the sale: pos (counter sale, the default),
	// fiber_jointing (a one-time fiber jointing / cable repair service charge),
	// or any future service type. Filters on the sales page use it to separate
	// monthly-package-ish rows from one-time services.
	SaleType string `gorm:"type:varchar(30);default:'pos';index" json:"saleType"`

	// PaidAmount is the money actually received against this sale. For an
	// ordinary POS sale it equals TotalAmount; for a promise or fiber jointing
	// sale it is kept in step with the linked debt record so the sales list can
	// show Received / Remaining without a join.
	PaidAmount float64 `gorm:"type:decimal(10,2);not null;default:0" json:"paidAmount"`
	// PaymentStatus mirrors the debt record's status (paid, partial, promise,
	// unpaid) so the sales list can filter and label service charges.
	PaymentStatus string `gorm:"type:varchar(20)" json:"paymentStatus"`

	// PromisePayment marks a sale row that was created when a customer settled an
	// existing POS promise at the counter. It has no product items and no stock
	// effect; it exists so the money received shows up in the sales list with a
	// Paid / Pending label instead of vanishing.
	PromisePayment bool `gorm:"default:false" json:"promisePayment"`

	// PromiseInfo is filled in when a sale was made on a promise-to-pay. It is
	// read from pos_promises rather than stored on the sale, so the money owed is
	// never duplicated and stays in step with what has actually been collected.
	PromiseInfo *SalePromiseInfo `gorm:"-" json:"promiseInfo"`
}

// SalePromiseInfo describes the unpaid part of a promise-to-pay sale.
type SalePromiseInfo struct {
	PromiseID       string  `json:"promiseId"`
	PendingAmount   float64 `json:"pendingAmount"`
	PaidAmount      float64 `json:"paidAmount"`
	CollectedAmount float64 `json:"collectedAmount"`
	RemainingAmount float64 `json:"remainingAmount"`
	PromiseDate     string  `json:"promiseDate"`
	Status          string  `json:"status"`
	Description     string  `json:"description"`
}

// SaleItem - Individual product in a Sale
type SaleItem struct {
	TenantModel
	SaleID        uuid.UUID `gorm:"type:uuid;not null;index" json:"saleId"`
	ProductID     uuid.UUID `gorm:"type:uuid;not null;index" json:"productId"`
	ProductName   string    `gorm:"type:varchar(255)" json:"productName"`
	Quantity      int       `gorm:"not null" json:"quantity"`
	Price         float64   `gorm:"type:decimal(10,2);not null" json:"price"`
	OriginalPrice float64   `gorm:"type:decimal(10,2);default:0" json:"originalPrice"`      // product list price at sale time
	TaxPercent    float64   `gorm:"type:decimal(5,2);not null;default:0" json:"taxPercent"` // tax % applied to this line
	SaleTax       float64   `gorm:"type:decimal(10,2);default:0" json:"saleTax"`
	WthTax        float64   `gorm:"type:decimal(10,2);default:0" json:"wthTax"`
	SerialNumber  string    `gorm:"type:text" json:"serialNumber"`
	Model         string    `gorm:"type:text" json:"model"`
}

// SubscriberInstallment tracks an installment agreement for a subscriber on a sale.
type SubscriberInstallment struct {
	TenantModel
	SaleID            uuid.UUID `gorm:"type:uuid;not null;index" json:"saleId"`
	SubscriberID      uuid.UUID `gorm:"type:uuid;not null;index" json:"subscriberId"`
	SubscriberName    string    `gorm:"type:varchar(255)" json:"subscriberName"`
	InstallmentPlanID uuid.UUID `gorm:"type:uuid;not null;index" json:"installmentPlanId"`
	PlanName          string    `gorm:"type:varchar(255)" json:"planName"`
	TotalInstallments int       `gorm:"not null" json:"totalInstallments"`
	PaidInstallments  int       `gorm:"not null;default:0" json:"paidInstallments"`
	InstallmentAmount float64   `gorm:"type:decimal(10,2);not null" json:"installmentAmount"`
	TotalAmount       float64   `gorm:"type:decimal(10,2);not null" json:"totalAmount"`
	NextInstallment   int       `gorm:"not null;default:1" json:"nextInstallment"`
	Status            string    `gorm:"type:varchar(20);default:'active'" json:"status"` // active, completed, defaulted
}
